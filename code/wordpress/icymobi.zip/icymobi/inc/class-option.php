<?php

class Inspius_Icymobi_Option{

	protected static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function get_option($id, $default = ''){
		$options = get_option( 'icymobi_config_option', array());
		if(isset($options[$id]) && $options[$id]!='')
			return $options[$id];
		else
			return $default;
	}

	public function render_field($type, $id, $attrs = array(), $default = ''){
		$attr_default = array(
			'label'			=> '', 
			'sub_label'		=> '', 
			'attrs' 		=> '', 
			'hidden_row'	=> false,
			'options' 		=> array(),
            'depends'       => '',
            'dependsValue'  => ''
		);

		$attrs = array_merge($attr_default, $attrs);

		$html = '<tr'.(($attrs['hidden_row'])?' style="display:none;"':'').'>
					<th scope="row">
						<label for="'.esc_attr($id).'">'. $attrs["label"] .'</label>
					</th>
					<td>
			';
		switch ($type) {
			case 'text':
				$html .= '<input '.$attrs["attrs"].' name="'.esc_attr($id).'" id="'.esc_attr($id).'" type="text" class="regular-text" value="'. esc_attr($this->get_option( $id, $default )) .'"> '.$attrs["sub_label"];
				break;
			case 'select':
				$option_value = $this->get_option( $id, $default );
				$html .= '<select '.$attrs["attrs"].' name="'.esc_attr($id).'" id="'.esc_attr($id).'" class="regular-select">';
					foreach ($attrs['options'] as $key => $value) {
						$html .= '<option value="'.$key.'" '. selected($option_value, $key, false) .'>'.$value.'</option>';
					}
				$html .= '</select>'. $attrs["sub_label"];
				break;
            case 'multiselect':
                $option_value = $this->get_option( $id, $default );
                $html .= '<input name="'.esc_attr($id).'" type="hidden" value="">';
                $html .= '<select '.$attrs["attrs"].' name="'.esc_attr($id).'" id="'.esc_attr($id).'" class="regular-select" multiple="multiple">';
                foreach ($attrs['options'] as $key => $value) {
                    $selected = in_array($key, explode(",", $option_value)) ? 'selected' : '';
                    $html .= '<option value="'.$key.'" '. $selected .'>'.$value.'</option>';
                }
                $html .= '</select>'. $attrs["sub_label"];
                break;
			case 'textarea':
				$html .= '<textarea '.$attrs["attrs"].' name="'.esc_attr($id).'" id="'.esc_attr($id).'" columns="30" rows="10" >'.$this->get_option( $id, $default ).'</textarea>';
				break;
			case 'checkbox':
				$html .= '
						<label for="'.esc_attr($id).'">
							<input name="'.esc_attr($id).'" id="'.esc_attr($id).'" type="checkbox" value="1" '.checked( $this->get_option($id, $default), 1, false ).'> 
							'.$attrs["sub_label"].'							
						</label>
				';
				break;
		}
		if(isset($attrs['description']) && $attrs['description']!=''){
			$html .= '<p class="description">'.$attrs['description'].'</p>';
		}
		$html .= '</td></tr>';

        if(isset($attrs['depends']) && $attrs['depends']!='' && isset($attrs['dependsValue']) && $attrs['dependsValue']!='') {
            $html .= '<script>var el = document.getElementById("' . $attrs['depends'] . '"), fn=function(){if(el.value=="' . $attrs['dependsValue'] . '"){document.getElementById("' . $id . '").parentElement.parentElement.style.display="";}else{document.getElementById("' . $id . '").parentElement.parentElement.style.display="none";}};el.addEventListener("change", function(){fn()}); fn()</script>';
        }

		echo $html;
	}
}
