<?php

class Inspius_Icymobi_Template extends Inspius_Icymobi_Option{

	private $add_ons;

	public function __construct(){
		$this->init_hooks();
	}

	public function init_hooks(){
		add_action("admin_menu", 				array($this, 'add_theme_menu_item'));

		// Register style and script
		add_action('admin_enqueue_scripts', 	array($this, 'register_scripts'));

		// Ajax Option
		add_action('wp_ajax_icymobi_save_option', 	array($this, 'save_data'));

		// Tabs
		add_action('icymobi_template_tab_content', 	array($this, 'render_general_page'), 10);
		add_action('icymobi_template_tab_content', 	array($this, 'render_contact_page'), 10);


		// Section Add Ons
		if ( false === ( $this->add_ons = get_transient( 'icymobi_addons_sections' ) ) ) {
			$this->add_ons = wp_remote_get('http://store.inspius.com/is-api/add-ons/');
			$this->add_ons = json_decode($this->add_ons['body']);

			if($this->add_ons){
				set_transient( 'icymobi_addons_sections', $this->add_ons, DAY_IN_SECONDS );
			}
		}
		if(count($this->add_ons)>0){
			add_action('icymobi_template_tab_content', 	array($this, 'render_add_ons_page'), 10);
			add_action('icymobi_option_tab_title', function(){
				echo '<a href="#icymobi-add-ons" class="nav-tab">Add-ons</a>';
			}, 100);
		}

		// Help Tab
		add_action('icymobi_action_add_help_tab', array($this, 'add_tab_general'), 10, 1);

		//Admin footer text
		add_filter( 'admin_footer_text', array( $this, 'admin_footer_text' ), 1 );

		add_action( 'after_setup_theme', array( $this, 'add_size_image') );

		add_action( 'admin_notices', array($this, 'check_requirement'), 10 );
	}

	public function check_requirement() {
		?>

		<?php if (version_compare( '5.4', phpversion(), '>' )): ?>
            <div class="error fade">
                <p><strong><?php echo "Icymobi requires PHP version 5.4 or above to be installed on your server."; ?></strong></p>
            </div>
		<?php endif; ?>

		<?php if (!is_plugin_active('woocommerce/woocommerce.php') || version_compare("2.6", WC()->version, '>')): ?>
            <div class="error fade">
                <p><strong><?php echo "Icymobi requires WooCommerce version 2.6 or above to be installed in your site."; ?></strong></p>
            </div>
		<?php endif; ?>

		<?php
	}

	public function add_size_image(){
		$width = $this->get_option('general_product_width', 500);
		$height = $this->get_option('general_product_height', 500);

		add_image_size('icymobi-image', $width, $height, true);
	}



	public function save_data(){
		$data = $_POST['data'];
		$data = json_decode( stripslashes( $data ) );
		$option = array();

		foreach ($data as $key => $value) {
			if (strpos($value->name, '[]') > -1) {
				if (isset($option[$value->name])) {
					$option[$value->name] = $option[$value->name] . ',' . $value->value;
				} else {
					$option[$value->name] = $value->value;
				}
			}  else {
				$option[$value->name] = $value->value;
			}
		}
		update_option( 'icymobi_config_option', $option );
		die;
	}

	public function register_scripts(){
		wp_enqueue_style( 'is-icymobi-style', plugins_url( 'icymobi/assets/css/style.css' ) );
		wp_enqueue_script( 'is-icymobi-map-script', '//maps.googleapis.com/maps/api/js?sensor=false&libraries=places&key=AIzaSyDgLR9YJJ9R46x1thdl8YS5QLSyTAUR7q8', array(), false, true);
		wp_enqueue_script( 'is-icymobi-script', plugins_url( 'icymobi/assets/js/main.js' ), array(), false, true );
	}

	public function theme_settings_page(){
		?>
		    <div class="wrap is-icymobi-wrap">
	            <h2 class="title">IcyMobi Configuration</h2>

	            <div class="message"></div>

	            <h2 class="nav-tab-wrapper">
	                <a href="#icymobi-general" class="nav-tab nav-tab-active">General</a>
	                <a href="#icymobi-contact-config" class="nav-tab" >Contact Page</a>
	                <?php do_action('icymobi_option_tab_title'); ?>

	            </h2>
	            <form id="icymobi_theme_options">

	            	<?php do_action('icymobi_template_tab_content'); ?>

		           	<div class="submit">
		           		<button class="button button-primary" id="icymobi_save_option" type="button">Save changes</button>

		           	</div>

		           	<div class="icon-loading">
						<div class='uil-squares-css' style='transform:scale(0.4);'><div><div></div></div><div><div></div></div><div><div></div></div><div><div></div></div><div><div></div></div><div><div></div></div><div><div></div></div><div><div></div></div></div>
		           	</div>
	        	</form>
	        </div>
		<?php
	}

	public function add_theme_menu_item(){
		global $icymobi_help_option;
		$icymobi_help_option = add_menu_page("IcyMobi", "IcyMobi", "manage_options", "icymobi-config", array($this, 'theme_settings_page'), plugins_url( 'icymobi/assets/images/logo.png' ), 30);
		add_action('load-'.$icymobi_help_option, array($this, 'add_help_tab'));
	}

	public function add_help_tab(){
		global $icymobi_help_option;
	    $screen = get_current_screen();

	    if ( $screen->id != $icymobi_help_option )
	        return;

	    do_action('icymobi_action_add_help_tab', $screen);
	}

	public function add_tab_general($screen){
		$screen->add_help_tab( array(
	        'id'	=> 'icymobi_general_tab',
	        'title'	=> __('General'),
	        'content'	=> "<h2><a href=''>IcyMobi</a> – General Settings</h2>".
						   '<iframe width="560" height="315" src="https://www.youtube.com/embed/MHxdFvg_MsE" frameborder="0" allowfullscreen></iframe>'
			,

	    ) );
		$screen->add_help_tab( array(
	        'id'	=> 'icymobi_contact_tab',
	        'title'	=> __('Contact Page'),
	        'content'	=> "<h2><a href=''>IcyMobi</a> – Contact Page Settings</h2>".
						   '<iframe width="560" height="315" src="https://www.youtube.com/embed/pSzMR3QJ0ko" frameborder="0" allowfullscreen></iframe>'
			,

	    ) );


	    $screen->set_help_sidebar(
			'<p><strong>For more information:</strong></p>' .
			'<p><a href="http://icymobi.com/about-us" target="_blank">About IcyMobi</a></p>'.
			'<p><a href="http://store.inspius.com/downloads/category/icymobi/" target="_blank">Official Plugins</a></p>'.
			'<p><a href="http://icymobi.com/help" target="_blank">Help & Support</a></p>'.
			'<p><a href="http://icymobi.com/found-a-bug" target="_blank">Found a bug?</a></p>'
		);
	}

	public function render_add_ons_page(){
		$products = $this->add_ons;
		include_once('templates/add-ons.php');
	}

	public function render_general_page(){
		include_once('templates/general.php');
	}

	public function render_contact_page(){
		include_once('templates/contact.php');
	}

	/**
	 * Change the admin footer text on WooCommerce admin pages.
	 *
	 * @since  2.3
	 * @param  string $footer_text
	 * @return string
	 */
	public function admin_footer_text( $footer_text ) {
		$footer_text = __( 'Thank you for selling with IcyMobi.', 'icymobi' );

		return $footer_text;
	}


}

if(is_admin()){
	new Inspius_Icymobi_Template();
}