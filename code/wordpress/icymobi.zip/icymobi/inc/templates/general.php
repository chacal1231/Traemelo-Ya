<div id="icymobi-general" class="tab-content active">
	<?php
	/**
	 * category page show options
	 */
	?>
	<h2>Category Display Options</h2>
	<table class="form-table form-general">
		<?php
			$this->render_field(
				'select',
				'general_category_display',
				array(
					'label' 	=> 'Category Page Display',
					'options' 	=> array(
							'products' 		=> 'Show Products',
							'subcategories' => 'Show Sub Categories',
							// 'both' 			=> 'Show categories & products',
						)
				),
				'products'
			);
		?>

		<?php
		/*$this->render_field(
			'select',
			'general_category_number',
			array(
				'label' 	=> 'Number of Categories Per Page',
				'options' 	=> array(
					'10' 	=> '10 categories',
					'20'	=> '20 categories',
					'50'	=> '50 categories',
					'100'	=> '100 categories'
				)
			),
			'20'
		);*/
		?>

		<?php
		$this->render_field(
			'select',
			'general_category_order_by',
			array(
				'label' 	=> 'Sort Categories By',
				'options' 	=> array(
					'id' 	=> 'ID',
					'name'	=> 'Category Name'
				)
			),
			'name'
		);
		?>

		<?php
		$this->render_field(
			'select',
			'general_category_order_direction',
			array(
				'label' 	=> 'Sort Direction',
				'options' 	=> array(
					'asc' 	=> 'Ascending',
					'desc'	=> 'Descending'
				)
			),
			'asc'
		);
		?>
	</table>

	<?php
	/**
	 * product page show options
	 */
	?>
	<h2>Product Display Options</h2>
	<table class="form-table form-general">
		<?php
		$this->render_field(
			'select',
			'general_product_order_by',
			array(
				'label' 	=> 'Sort Products By',
				'options' 	=> array(
					'id' 	=> 'ID',
					'title'	=> 'Product Name',
					'date' 	=> 'Date Created'
				)
			),
			'date'
		);
		?>

		<?php
		$this->render_field(
			'select',
			'general_product_order_direction',
			array(
				'label' 	=> 'Sort Direction',
				'options' 	=> array(
					'asc' 	=> 'Ascending',
					'desc'	=> 'Descending'
				)
			),
			'asc'
		);
		?>
	</table>

	<?php
	/**
	 * product image options
	 */
	?>
	<h2>Product Images</h2>
	<p>
		These settings affect the display and dimensions of images in your app. After changing these settings you may need to <a href="https://wordpress.org/extend/plugins/regenerate-thumbnails/">regenerate your thumbnails</a>.
	</p>
	<table class="form-table form-general">
		<?php
			$this->render_field('text', 'general_product_width', 	array('label'=> 'Width', 'sub_label'=> 'px'), 500);
			$this->render_field('text', 'general_product_height', 	array('label'=> 'Height', 'sub_label'=> 'px'), 500);
		?>
	</table>

	<?php
	/**
	 * Blogs display options
	 */
	?>
	<h2>Blog Settings</h2>
	<table class="form-table form-general">
		<?php
		$this->render_field(
			'select',
			'general_blog_display',
			array(
				'label' 	=> 'Blog Page Display',
				'options' 	=> array(
					'posts' 				=> 'Show All Blog Posts',
					'categories' 			=> 'Show Blogs Categories',
					'specific_categories' 	=> 'Show posts from specific categories'
				)
			),
			'categories'
		);


		$categories = get_categories();
		$options = [];
		foreach ($categories as $category) {
			$options[$category->cat_ID] = $category->cat_name;
		}
		$this->render_field(
			'multiselect',
			'general_blog_categories[]',
			array(
				'label' 	=> 'Display Blogs Of Categories',
				'options' 	=> $options,
				'depends'       => 'general_blog_display',
				'dependsValue'  => 'specific_categories'
			),
			''
		);
		?>
	</table>

	<?php
	/**
	 * maintenance options
	 */
	?>
	<h2>Maintenance Settings</h2>
	<table class="form-table form-general">
		<?php
			$this->render_field('checkbox', 'general_enable_app', 	array('label'=> 'Maintenance Mode', 'sub_label'=> 'Enable Maintenance Mode'), 0);
			$this->render_field('textarea', 'general_maintenance_text', 	array('label'=> 'Maintenance Mode Text'));
		?>
	</table>
</div>