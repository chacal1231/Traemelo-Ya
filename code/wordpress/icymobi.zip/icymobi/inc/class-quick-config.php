<?php

class Inspius_Icymobi_Quick_Config{

	public function __construct(){
		add_action('init', array($this, 'setup_config'));
	}

	public function setup_config(){
		$currentId = $this->check_key();
        if($currentId !== false){
			$this->create_keys($currentId);
			flush_rewrite_rules();
		}
	}

	private function check_key(){
		global $wpdb;
		$key_count = $wpdb->get_var( $wpdb->prepare( 
			"
				SELECT COUNT(*) 
				FROM {$wpdb->prefix}woocommerce_api_keys
				WHERE description = %s
			", 
			'ICYMOBI API'
		) );
		if($key_count>0) {
			return false;
        } else {
				$currentId = $wpdb->get_var($wpdb->prepare(
					"
							SELECT MAX(key_id) AS key_max
							FROM {$wpdb->prefix}woocommerce_api_keys
					"
				));
//                        $currentId = $queryRaw;
				return $currentId;
		}
	}


	private function create_keys($currentId) {
		global $wpdb;

		$description = 'ICYMOBI API';
		$user        = wp_get_current_user();

		// Created API keys.
		$permissions     = 'read_write';
		$consumer_key    = 'ck_' . wc_rand_hash();
		$consumer_secret = 'cs_' . wc_rand_hash();

		$wpdb->insert(
			$wpdb->prefix . 'woocommerce_api_keys',
			array(
                                'key_id'          => (int)($currentId + 1),
				'user_id'         => $user->ID,
				'description'     => $description,
				'permissions'     => $permissions,
				'consumer_key'    => wc_api_hash( $consumer_key ),
				'consumer_secret' => $consumer_secret,
				'truncated_key'   => substr( $consumer_key, -7 )
			),
			array(
				'%d',
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s'
			)
		);
		update_option( 'icymobi_api_tokens', array(
			'consumer_key' 		=> $consumer_key,
			'consumer_secret' 	=> $consumer_secret
		) );
	}

}
new Inspius_Icymobi_Quick_Config();