<?php

/**
 * Created by PhpStorm.
 * User: phongnguyen
 * Date: 6/16/16
 * Time: 3:57 PM
 */
class Inspius_Blog extends AbstractApi
{
    const REQUEST_SINGLE = 'single';
    const REQUEST_SEARCH = 'search';
    const REQUEST_CATEGORY = 'category';
    const REQUEST_TAG = 'tag';
    const ADD_NEW_COMMENT = 'add';
    const REQUEST_GET_CATEGORY = 'get_category';

    public function response($params = [])
    {
        $data = [
            'post_type' => 'post',
            'post_status' => 'publish'
        ];
        $type = $this->_getParam('type');
        $param = $this->_getParam('param');
        $isSingle = false;

        // get product by type
        switch ($type) {
            case self::REQUEST_SINGLE:
                if ($param) {
                    $data['p'] = $param;
                    $isSingle = true;
                }
                break;
            case self::REQUEST_CATEGORY:
                if ($param) {
                    $data['cat'] = $param;
                }
                break;
            case self::REQUEST_SEARCH:
                if ($param) {
                    $data['s'] = $param;
                }
                break;
            case self::REQUEST_TAG:
                if ($param) {
                    $data['tag'] = $param;
                }
                break;
            case self::ADD_NEW_COMMENT:
                if ($param) {
                    $this->_addNewComment($param);
                    return null;
                } else {
                    throw new Exception(Inspius_Status::COMMENT_ADD_NEW_FAILED);
                }
            case self::REQUEST_GET_CATEGORY:
                return $this->_getCategoryList();
            default:
                break;
        }

        // additional params
        if ($order = $this->_getParam('order')) {
            $data['order'] = $order;
        }
        if ($orderBy = $this->_getParam('orderby')) {
            $data['orderby'] = $orderBy;
        }
        if ($page = $this->_getParam('page')) {
            $data['paged'] = $page;
        }
        if ($perPage = $this->_getParam('per_page')) {
            $data['posts_per_page'] = $perPage;
        }

        $the_query = new WP_Query($data);
        return $this->_formatPost($the_query, $isSingle);
    }

    private function _getCategoryList()
    {
        $categories = get_categories();
        $displayType = $this->get_option('general_blog_display', 'categories');
        if ($displayType == 'specific_categories') {
            $specificCategoryList = $this->get_option('general_blog_categories[]');
            $specificCategoryList = explode(',', $specificCategoryList);
            $categoryList = [];
            foreach ($categories as $category) {
                if (in_array($category->cat_ID, $specificCategoryList)) {
                    $categoryList[] = $category;
                }
            }
            return $categoryList;
        }
        return $categories;
    }

    private function _formatPost($the_query, $isSingle = false)
    {
        /* @var $the_query WP_Query */
        $formattedPosts = [];
        while ($the_query->have_posts()) {
            $the_query->the_post();

            $content = get_the_content();
            $content = apply_filters('the_content', $content);
            $content = str_replace(']]>', ']]&gt;', $content);
            $featuredImage = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );
            if(!$featuredImage) {
                $featuredImage = '';
            }
            
            $formattedPosts[] = [
                'id' => get_the_ID(),
                'post_author' => get_the_author(),
                'post_content' => $isSingle ? $content : '',
                'post_title' => get_the_title(),
                'post_excerpt' => get_the_excerpt(),
                'post_link' => get_the_permalink(),
                'post_image' => $featuredImage,
                'post_date' => get_the_date(),
                'post_tags' => get_the_tags(),
                'post_categories' => get_the_category(),
                'post_comment' => $this->_formatComments(get_comments(['post_id' => get_the_ID()]))
            ];
        }
        return $formattedPosts;
    }
    
    public function catch_that_image()
    {
        global $post, $posts;
        $first_img = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        $first_img = $matches [1] [0];
        
        return $first_img;
    }

    private function _formatComments($comments)
    {
        $result = [];
        foreach ($comments as $comment) {
            $comment->date_created = wc_rest_prepare_date_response($comment->comment_date_gmt);
            $comment->link_avatar = get_avatar_url($comment->comment_author_email, array('size' => 80));
            $result[] = $comment;
        }
        return $result;
    }


    /**
     * @param $id
     * @throws Exception
     */
    protected function _addNewComment($id)
    {
        $params = $this->_getParams(
            ['user_id', 'user_login', 'user_email', 'comment'],
            ['user_id', 'comment_author', 'comment_author_email', 'comment_content']
        );

        $params['comment_post_ID'] = $id;
        $params['comment_author_IP'] = $_SERVER['REMOTE_ADDR'];
        $params['comment_agent'] = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        $params['comment_date'] = current_time('mysql');
        $params['comment_date_gmt'] = current_time('mysql', 1);
        if (!isset($params['user_id']) || !$params['user_id'] || !is_numeric($params['user_id'])) $params['user_id'] = 0;

        if ($params['user_id'] != 0) {
            $customerId = $params['user_id'];
            $customer = $this->wc_api->get("customers/$customerId");
            $params['comment_author'] = $customer['username'];
            $params['comment_author_email'] = $customer['email'];
        }

        $params = wp_filter_comment($params);

        $params['comment_approved'] = $this->_check_comment($params);

        if (!wp_insert_comment($params)) {
            throw new Exception(Inspius_Status::REVIEW_ADD_NEW_FAILED);
        }
    }

    /**
     * check comment
     *
     * @param $commentdata
     * @return int|mixed|string|void
     * @throws Exception
     */
    private function _check_comment($commentdata)
    {
        global $wpdb;

        // Simple duplicate check
        // expected_slashed ($comment_post_ID, $comment_author, $comment_author_email, $comment_content)
        $dupe = $wpdb->prepare(
            "SELECT comment_ID FROM $wpdb->comments WHERE comment_post_ID = %d AND comment_parent = %s AND comment_approved != 'trash' AND ( comment_author = %s ",
            wp_unslash($commentdata['comment_post_ID']),
            wp_unslash($commentdata['comment_parent']),
            wp_unslash($commentdata['comment_author'])
        );
        if ($commentdata['comment_author_email']) {
            $dupe .= $wpdb->prepare(
                "OR comment_author_email = %s ",
                wp_unslash($commentdata['comment_author_email'])
            );
        }
        $dupe .= $wpdb->prepare(
            ") AND comment_content = %s LIMIT 1",
            wp_unslash($commentdata['comment_content'])
        );

        $dupe_id = $wpdb->get_var($dupe);

        /**
         * Filters the ID, if any, of the duplicate comment found when creating a new comment.
         *
         * Return an empty value from this filter to allow what WP considers a duplicate comment.
         *
         * @since 4.4.0
         *
         * @param int $dupe_id ID of the comment identified as a duplicate.
         * @param array $commentdata Data for the comment being created.
         */
        $dupe_id = apply_filters('duplicate_comment_id', $dupe_id, $commentdata);

        if ($dupe_id) {
            /**
             * Fires immediately after a duplicate comment is detected.
             *
             * @since 3.0.0
             *
             * @param array $commentdata Comment data.
             */
            throw new Exception(Inspius_Status::REVIEW_ADD_NEW_DUPLICATED);
        }

        /**
         * Fires immediately before a comment is marked approved.
         *
         * Allows checking for comment flooding.
         *
         * @since 2.3.0
         *
         * @param string $comment_author_IP Comment author's IP address.
         * @param string $comment_author_email Comment author's email.
         * @param string $comment_date_gmt GMT date the comment was posted.
         */
        do_action(
            'check_comment_flood',
            $commentdata['comment_author_IP'],
            $commentdata['comment_author_email'],
            $commentdata['comment_date_gmt']
        );

        if (!empty($commentdata['user_id'])) {
            $user = get_userdata($commentdata['user_id']);
            $post_author = $wpdb->get_var($wpdb->prepare(
                "SELECT post_author FROM $wpdb->posts WHERE ID = %d LIMIT 1",
                $commentdata['comment_post_ID']
            ));
        }

        if (isset($user) && ($commentdata['user_id'] == $post_author || $user->has_cap('moderate_comments'))) {
            // The author and the admins get respect.
            $approved = 1;
        } else {
            // Everyone else's comments will be checked.
            if (check_comment(
                $commentdata['comment_author'],
                $commentdata['comment_author_email'],
                $commentdata['comment_author_url'],
                $commentdata['comment_content'],
                $commentdata['comment_author_IP'],
                $commentdata['comment_agent'],
                $commentdata['comment_type']
            )) {
                $approved = 1;
            } else {
                $approved = 0;
            }

            if (wp_blacklist_check(
                $commentdata['comment_author'],
                $commentdata['comment_author_email'],
                $commentdata['comment_author_url'],
                $commentdata['comment_content'],
                $commentdata['comment_author_IP'],
                $commentdata['comment_agent']
            )) {
                $approved = EMPTY_TRASH_DAYS ? 'trash' : 'spam';
            }
        }

        /**
         * Filter a comment's approval status before it is set.
         *
         * @since 2.1.0
         *
         * @param bool|string $approved The approval status. Accepts 1, 0, or 'spam'.
         * @param array $commentdata Comment data.
         */
        $approved = apply_filters('pre_comment_approved', $approved, $commentdata);
        return $approved;
    }

    private function get_option($id, $default = '')
    {
        $options = get_option('icymobi_config_option', array());
        if (isset($options[$id]) && $options[$id] != '')
            return $options[$id];
        else
            return $default;
    }
}