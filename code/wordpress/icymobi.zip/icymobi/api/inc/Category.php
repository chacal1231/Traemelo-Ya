<?php

/**
 * Created by PhpStorm.
 * User: phongnguyen
 * Date: 6/16/16
 * Time: 3:57 PM
 */
class Inspius_Category extends AbstractApi
{
    public function response($params = [])
    {
        $data = [
            'page' => 1,
            'per_page' => 100,
            'orderby' => Inspius_Icymobi_Option::instance()->get_option('general_category_order_by', 'name'),
            'order' => Inspius_Icymobi_Option::instance()->get_option('general_category_order_direction', 'asc')
        ];

        if ($order = $this->_getParam('order')) {
            $data['order'] = $order;
        }
        if ($orderBy = $this->_getParam('orderby')) {
            $data['orderby'] = $orderBy;
        }
        if ($page = $this->_getParam('page')) {
            $data['page'] = $page;
        }
        if ($perPage = $this->_getParam('per_page')) {
            if ($perPage !== 'all') {
                $data['per_page'] = $perPage;
            }
        }
        $categoriesRaw = array();
        do {
            $responseRaw = $this->wc_api->get('products/categories', $data);
            $categoriesRaw = array_merge($categoriesRaw, $responseRaw);
            $data['page'] += 1;
        } while(!empty($responseRaw));

        if (Inspius_Icymobi_Option::instance()->get_option('general_category_display', 'products') == 'products') {
            return $categoriesRaw;
        } else {
            return $this->setup_data($categoriesRaw);
        }

    }

    private function setup_data($response)
    {
        $data = array();
        foreach ($response as $category) {
            if ($category['parent'] === 0) {
                $category['children'] = $this->get_children_category($category['id'], $response);
                array_push($data, $category);
            }
        }
        return $data;
    }


    private function get_children_category($parent, $list_category)
    {
        $children = array();
        foreach ($list_category as $category) {
            if ($category['parent'] === $parent) {
                $category['children'] = $this->get_children_category($category['id'], $list_category);
                array_push($children, $category);
            }
        }
        return $children;
    }
}