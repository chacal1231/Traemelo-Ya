<?php

    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    require_once('api.php');
    // require_once('../modules/productcomments/ProductComment.php');
    require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/productcomments/ProductComment.php');

    class IcymobiReviewsModuleFrontController extends AbstractIcymobiApiFrontController
    {

        const CREATE_REVIEW = 'add';
        const REQUEST_REVIEW = 'get';

        public $ProductComment;

        public function __construct()
        {
            parent::__construct();
        }

        protected function _getResponse()
        {
            if (!Module::isInstalled('productcomments') || !Module::isEnabled('productcomments')) {
                throw new Exception('shop not enable comment feature');
            }
            if (file_exists(dirname(dirname(dirname(dirname(__FILE__)))) . '/productcomments/ProductComment.php')) {
                include_once dirname(dirname(dirname(dirname(__FILE__)))) . '/productcomments/ProductComment.php';
                $this->ProductComment = new ProductComment();
            }
            $id = Tools::getValue('id');
            $task = Tools::getValue('task');
            if ($id && is_numeric($id)) {
                if ($id && $task == self::CREATE_REVIEW) {
                    return $this->createReviewProduct($id);
                }

                return $this->getReviewProduct($id);
            }
            throw new Exception(MessageIcy::REVIEW_ID_NOT_FOUND);
        }

        public function createReviewProduct($id)
        {
            $user_login = Tools::getValue('user_login');
            $user_email = Tools::getValue('user_email');
            $comment = Tools::getValue('comment');
            $rating = intval(Tools::getValue('rating'));
            $id_customer = Tools::getValue('user_id', 0);

            if (!$id_customer && !Configuration::get('PRODUCT_COMMENTS_ALLOW_GUESTS'))
                throw new Exception(MessageIcy('You must be connected in order to send a comment'));

            if (!$comment || !Validate::isMessage($comment))
                throw new Exception('Comment is incorrect');
            if (!$id_customer && !$user_login && !$user_email && !Validate::isEmail($user_email))
                throw new Exception('User info is incorrect');
            if (!($rating))
                throw new Exception('You must give a rating');

            $product = new Product($id);
            if (!$product->id)
                throw new Exception('Product not found');

            $id_guest = 0;

            $customer_comment = $this->ProductComment->getByCustomer($id, $id_customer, true, $id_guest);
            if (!$customer_comment || ($customer_comment && (strtotime($customer_comment['date_add']) + (int) Configuration::get('PRODUCT_COMMENTS_MINIMAL_TIME')) < time())) {

                $commentObj = new ProductComment();
                $commentObj->content = strip_tags($comment);
                $commentObj->id_product = (int) $id;
                $commentObj->id_customer = (int) $id_customer;
                $commentObj->id_guest = $id_guest;
                $commentObj->customer_name = $user_login;
                $commentObj->title = Tools::getValue('title');
                $commentObj->grade = $rating;
                $commentObj->validate = 0;
                $commentObj->save();
            } else {
                throw new Exception('Please wait before posting another comment' . ' ' . Configuration::get('PRODUCT_COMMENTS_MINIMAL_TIME') . ' ' . 'seconds before posting a new comment');
            }
        }

        public function getReviewProduct($id_product)
        {
            $arrayRawComments = $this->ProductComment->getByProduct($id_product);

            return $this->formatArrayCommentsByReference($arrayRawComments);
        }

        public function formatArrayCommentsByReference(&$arrayComments)
        {
            foreach ($arrayComments as &$comment) {
                # code...
                $comment['id'] = (int) $comment['id_product_comment'];
                $comment['date_created'] = $comment['date_add'];
                $comment['name'] = $comment['customer_name'];
                $comment['email'] = '';
                $comment['review'] = $comment['content'];
                $comment['rating'] = (int) $comment['grade'];
                $comment['_links'] = array(
                    'self'       => array(
                        array('href' => '')
                    ),
                    'collection' => array(
                        array('href' => '')
                    ),
                    'up'         => array(
                        array('href' => '')
                    )
                );
                $comment['link_avatar'] = '';
                unset($comment['id_product_comment']);
                unset($comment['date_add']);
                unset($comment['customer_name']);
                unset($comment['grade']);
                unset($comment['content']);
                unset($comment['title']);
                unset($comment['total_advice']);
                unset($comment['total_useful']);
            }
            return $arrayComments;
        }

    }
    