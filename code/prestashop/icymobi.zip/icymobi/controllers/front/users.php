<?php

    /**
     * Copyright © 2016 Inspius. All rights reserved.
     * Author: Khanh Tran
     * Author URI: http://inspius.com
     */
    require_once("api.php");

    class IcymobiUsersModuleFrontController extends AbstractIcymobiApiFrontController
    {

        const USER_ACTION_LOGIN = 'login';
        const USER_ACTION_LOGIN_SOCIAL = 'loginSocial';
        const USER_ACTION_REGISTER = 'register';
        const USER_ACTION_FORGOT = 'forgot';
        const USER_ACTION_UPDATE = 'update';
        const USER_ACTION_UPDATE_SHIPPING = 'update_shipping';
        const USER_ACTION_UPDATE_BILLING = 'update_billing';

        protected $id_lang_default;

        public function __construct()
        {
            parent::__construct();
            $this->id_lang_default = Configuration::get('PS_LANG_DEFAULT');
        }

        protected function _getResponse()
        {
            $data = array();
            $task = Tools::getValue('task');
            if ($task) {
                switch ($task) {
                    case self::USER_ACTION_LOGIN:
                        $data = $this->_login();
                        break;
                    case self::USER_ACTION_LOGIN_SOCIAL:
                        $data = $this->handleLoginSocial();
                        break;
                    case self::USER_ACTION_REGISTER:
                        $data = $this->_register();
                        break;
                    case self::USER_ACTION_FORGOT:
                        $this->_forgotPassword();
                        break;
                    case self::USER_ACTION_UPDATE:
                        $data = $this->_updateCustomer();
                        break;
                    case self::USER_ACTION_UPDATE_BILLING:
                        $data = $this->_updateAddress();
                        break;
                    case self::USER_ACTION_UPDATE_SHIPPING:
                        $data = $this->_updateAddress(false);
                        break;
                    default:
                        break;
                }
                return $data;
            }
            throw new Exception(MessageIcy::USER_NO_ROUTE);
        }
        
        function handleLoginSocial() 
        {
            $platform = Tools::getValue('socialPlatform');
            if($platform  == 'google') {
                return $this->_loginGoogleSocial();
            }
            if($platform == 'facebook') {
                return $this->_loginFacebookSocial();
            }
        }
            
        protected function _loginFacebookSocial()
        {
            $passwd = 'facebook123';
            $email = Tools::getValue('email');
            $gender = Tools::getValue('gender');
            $name = Tools::getValue('name');
//            $picture = Tools::getValue('picture');
            $picture = Tools::getValue('picture_large');
            if($gender && $gender == 'male') {
                $id_gender = 1;
            } elseif($gender && $gender == 'female') {
                $id_gender = 2;
            } else {
                $id_gender = 0;
        }
        
            
            $userObj = new Customer();
            $exists = $userObj->customerExists($email);
            if (!$exists == TRUE) {
                $user = new Customer();
                
                $user->firstname = substr($name, 0, strpos($name ,' ', 0));
                $user->lastname = substr($name, strpos($name ,' ', 0));
                $user->email = $email;
                $user->id_gender = $id_gender;
                $user->passwd = Tools::encrypt($passwd);
                $user->newsletter = 0;

                $user->id_shop = ($user->id_shop) ? $user->id_shop : Context::getContext()->shop->id;
                $user->id_shop_group = ($user->id_shop_group) ? $user->id_shop_group : Context::getContext()->shop->id_shop_group;
                $user->id_lang = ($user->id_lang) ? $user->id_lang : Context::getContext()->language->id;
                $user->secure_key = md5(uniqid(rand(), true));
                $user->last_passwd_gen = date('Y-m-d H:i:s', strtotime('-' . Configuration::get('PS_PASSWD_TIME_FRONT') . 'minutes'));

                $success = $user->add($autodate = true, $null_values = true);
                if ($success == FALSE) {
                    throw new Exception('Sorry ,something is wrong!');
                }
                $user->updateGroup($user->groupBox);
            } else {
                $user = $userObj->getByEmail($email);
            }
            $return = array (
                "id"            => (int) $user->id,
                "date_created"  => "$user->date_add",
                "date_modified" => $user->date_upd,
                "email"         => $user->email,
                "first_name"    => $user->firstname,
                "last_name"     => $user->lastname,
                "username"      => null,
                "last_order"    => array(
                    "id"   => "",
                    "date" => ""
                ),
                "orders_count"  => 0,
                "total_spent"   => "0.00",
                "avatar_url"    => "$picture",
                "billing"       => array(
                    "first_name" => "",
                    "last_name"  => "",
                    "company"    => "",
                    "address_1"  => "",
                    "address_2"  => "",
                    "city"       => "",
                    "state"      => "",
                    "postcode"   => "",
                    "country"    => "",
                    "email"      => "",
                    "phone"      => ""
                ),
                "shipping"      => array(
                    "first_name" => "",
                    "last_name"  => "",
                    "company"    => "",
                    "address_1"  => "",
                    "address_2"  => "",
                    "city"       => "",
                    "state"      => "",
                    "postcode"   => "",
                    "country"    => ""
                ),
                "_links"        => array(
                    "self"       => array(
                        array(
                            "href" => ''
                        )
                    ),
                    "collection" => array(
                        array(
                            "href" => ""
                        )
                    )
                ),
                "avatar"        => ""
            );
            return $return;
        }
        protected function _loginGoogleSocial()
        {
            $passwd = 'google123';
            $email = Tools::getValue('email');
            $gender = Tools::getValue('gender');
            $name = Tools::getValue('name');
            $picture = Tools::getValue('picture');
            if($gender && $gender == 'male') {
                $id_gender = 1;
            } elseif($gender && $gender == 'female') {
                $id_gender = 2;
            } else {
                $id_gender = 0;
            }
            
            
            $userObj = new Customer();
            $exists = $userObj->customerExists($email);
            if (!$exists == TRUE) {
                $user = new Customer();
                
                $user->firstname = substr($name, 0, strpos($name ,' ', 0));
                $user->lastname = substr($name, strpos($name ,' ', 0));
                $user->email = $email;
                $user->id_gender = $id_gender;
                $user->passwd = Tools::encrypt($passwd);
                $user->newsletter = 0;

                $user->id_shop = ($user->id_shop) ? $user->id_shop : Context::getContext()->shop->id;
                $user->id_shop_group = ($user->id_shop_group) ? $user->id_shop_group : Context::getContext()->shop->id_shop_group;
                $user->id_lang = ($user->id_lang) ? $user->id_lang : Context::getContext()->language->id;
                $user->secure_key = md5(uniqid(rand(), true));
                $user->last_passwd_gen = date('Y-m-d H:i:s', strtotime('-' . Configuration::get('PS_PASSWD_TIME_FRONT') . 'minutes'));

                $success = $user->add($autodate = true, $null_values = true);
                if ($success == FALSE) {
                    throw new Exception('Sorry ,something is wrong!');
                }
                $user->updateGroup($user->groupBox);
            } else {
                $user = $userObj->getByEmail($email);
            }
            $return = array (
                "id"            => (int) $user->id,
                "date_created"  => "$user->date_add",
                "date_modified" => $user->date_upd,
                "email"         => $user->email,
                "first_name"    => $user->firstname,
                "last_name"     => $user->lastname,
                "username"      => null,
                "last_order"    => array(
                    "id"   => "",
                    "date" => ""
                ),
                "orders_count"  => 0,
                "total_spent"   => "0.00",
                "avatar_url"    => "$picture",
                "billing"       => array(
                    "first_name" => "",
                    "last_name"  => "",
                    "company"    => "",
                    "address_1"  => "",
                    "address_2"  => "",
                    "city"       => "",
                    "state"      => "",
                    "postcode"   => "",
                    "country"    => "",
                    "email"      => "",
                    "phone"      => ""
                ),
                "shipping"      => array(
                    "first_name" => "",
                    "last_name"  => "",
                    "company"    => "",
                    "address_1"  => "",
                    "address_2"  => "",
                    "city"       => "",
                    "state"      => "",
                    "postcode"   => "",
                    "country"    => ""
                ),
                "_links"        => array(
                    "self"       => array(
                        array(
                            "href" => ''
                        )
                    ),
                    "collection" => array(
                        array(
                            "href" => ""
                        )
                    )
                ),
                "avatar"        => ""
            );
            return $return;
        }

        protected function _login()
        {
            $passwd = trim(Tools::getValue('user_pass'));
            $_POST['user_pass'] = null;
            $email = trim(Tools::getValue('user_login'));
            if (empty($email)) {
                throw new Exception('An email address required.');
            } elseif (!Validate::isEmail($email)) {
                throw new Exception('Invalid email address.');
            } elseif (empty($passwd)) {
                throw new Exception('Password is required.');
            } elseif (!Validate::isPasswd($passwd)) {
                throw new Exception('Invalid password.');
            } else {
                $customer = new Customer();
                $authentication = $customer->getByEmail(trim($email), trim($passwd));
                if (isset($authentication->active) && !$authentication->active) {
                    throw new Exception('Your account isn\'t available at this time, please contact us');
                } elseif (!$authentication || !$customer->id) {
                    throw new Exception('Authentication failed.');
                } else {
                    $arrayCustomerAddress = $customer->getAddresses($this->id_lang_default);
                }
            }
            
            $customerOrders = Order::getCustomerOrders($customer->id);
            $lastCustomerOrder = array_shift($customerOrders);
            $customerUsefulInfoOrders = $customer->getStats();
            
            $customerLink = _PS_BASE_URL_ . __PS_BASE_URI__ . 'api/customers/' . $customer->id;

            $return = array(
                "id"            => intval($customer->id),
                "date_created"  => ($customer->date_add),
                "date_modified" => $customer->date_upd,
                "email"         => $customer->email,
                "first_name"    => $customer->firstname,
                "last_name"     => $customer->lastname,
                "username"      => "",
                "avatar"        => "",
                "last_order"    => array(
                    "id"   => isset($lastCustomerOrder) ? $lastCustomerOrder['id_order'] : 0,
                    "date" => isset($lastCustomerOrder) ? $lastCustomerOrder['date_add'] : 0
                ),
                "orders_count"  => isset($customerUsefulInfoOrders) ? $customerUsefulInfoOrders['nb_orders'] : 0,
                "total_spent"   => isset($customerUsefulInfoOrders) ? $customerUsefulInfoOrders['total_orders'] : 0,
                "avatar_url"    => "",
                "billing"       => array(
                    "first_name" => isset($arrayCustomerAddress[0]['firstname']) ? $arrayCustomerAddress[0]['firstname'] : '',
                    "last_name"  => isset($arrayCustomerAddress[0]['lastname']) ? $arrayCustomerAddress[0]['lastname'] : '',
                    "company"    => isset($arrayCustomerAddress[0]['company']) ? $arrayCustomerAddress[0]['company'] : '',
                    "address_1"  => isset($arrayCustomerAddress[0]['address1']) ? $arrayCustomerAddress[0]['address1'] : '',
                    "address_2"  => isset($arrayCustomerAddress[0]['address2']) ? $arrayCustomerAddress[0]['address2'] : '',
                    "city"       => isset($arrayCustomerAddress[0]['city']) ? $arrayCustomerAddress[0]['city'] : '',
                    "state"      => isset($arrayCustomerAddress[0]['state_name']) ? $arrayCustomerAddress[0]['state_name'] : '',
                    "postcode"   => isset($arrayCustomerAddress[0]['postcode']) ? $arrayCustomerAddress[0]['postcode'] : '',
                    "country"    => isset($arrayCustomerAddress[0]['country_name']) ? $arrayCustomerAddress[0]['country_name'] : '',
                    "email"      => $customer->email,
                    "phone"      => isset($arrayCustomerAddress[0]['phone_mobile']) ? $arrayCustomerAddress[0]['phone_mobile'] : ''
                ),
                "shipping"      => array(
                    "first_name" => isset($arrayCustomerAddress[0]['firstname']) ? $arrayCustomerAddress[0]['firstname'] : '',
                    "last_name"  => isset($arrayCustomerAddress[0]['lastname']) ? $arrayCustomerAddress[0]['lastname'] : '',
                    "company"    => isset($arrayCustomerAddress[0]['city']) ? $arrayCustomerAddress[0]['city'] : '',
                    "address_1"  => isset($arrayCustomerAddress[0]['address1']) ? $arrayCustomerAddress[0]['address1'] : '',
                    "address_2"  => isset($arrayCustomerAddress[0]['address2']) ? $arrayCustomerAddress[0]['address2'] : '',
                    "city"       => isset($arrayCustomerAddress[0]['city']) ? $arrayCustomerAddress[0]['city'] : '',
                    "state"      => isset($arrayCustomerAddress[0]['state_name']) ? $arrayCustomerAddress[0]['state_name'] : '',
                    "postcode"   => isset($arrayCustomerAddress[0]['postcode']) ? $arrayCustomerAddress[0]['postcode'] : '',
                    "country"    => isset($arrayCustomerAddress[0]['country_name']) ? $arrayCustomerAddress[0]['country_name'] : ''
                ),
                "_links"        => array(
                    "self"       => array(
                        array(
                            "href" => $customerLink
                        )
                    ),
                    "collection" => array(
                        array(
                            "href" => ""
                        )
                    )
                )
            );
            return $return;
        }

        protected function _register()
        {
            $user_login = Tools::getValue('user_login');
            $passwd = Tools::getValue('user_pass');
            $confirm_passwd = Tools::getValue('user_confirmpass');
            $user_email = Tools::getValue('user_email');
            $firstname = Tools::getValue('first_name');
            $lastname = Tools::getValue('last_name');
            $newsletter = Tools::getValue('newsletter');

            if ($passwd !== $confirm_passwd) {
                throw new Exception('user_pass and user_confirmpass does\'t matched ');
            }

            if (!Validate::isEmail($user_email) || ($passwd && !Validate::isPasswd($passwd))) {
                throw new Exception(MessageIcy::USER_REGISTER_INVALID_DATA);
            }
            if (empty($firstname) || empty($lastname) ||
                    !Validate::isName($firstname) || !Validate::isName($lastname)) {
                throw new Exception('first_name or last_name is incorrect.');
            }
            $user = new Customer();

            $exists = $user->customerExists($user_email);
            if ($exists == TRUE) {
                throw new Exception(MessageIcy::USER_REGISTER_EXISTING_USER_EMAIL);
            }
            $user->firstname = $firstname;
            $user->lastname = $lastname;
            $user->email = $user_email;
            $user->passwd = Tools::encrypt($passwd);
            $user->newsletter = ($newsletter == 1) ? 1 : 0;

            $user->id_shop = ($user->id_shop) ? $user->id_shop : Context::getContext()->shop->id;
            $user->id_shop_group = ($user->id_shop_group) ? $user->id_shop_group : Context::getContext()->shop->id_shop_group;
            $user->id_lang = ($user->id_lang) ? $user->id_lang : Context::getContext()->language->id;
            $user->birthday = (empty($user->years) ? $user->birthday : (int) $user->years . '-' . (int) $user->months . '-' . (int) $user->days);
            $user->secure_key = md5(uniqid(rand(), true));
            $user->last_passwd_gen = date('Y-m-d H:i:s', strtotime('-' . Configuration::get('PS_PASSWD_TIME_FRONT') . 'minutes'));

            $success = $user->add($autodate = true, $null_values = true);
            $user->updateGroup($user->groupBox);

            if ($success == FALSE) {
                throw new Exception('Sorry ,something is wrong!');
            }

            $customerLink = _PS_BASE_URL_ . __PS_BASE_URI__ . 'api/customers/' . $user->id;

            $return = array (
                "id"            => (int) $user->id,
                "date_created"  => "$user->date_add",
                "date_modified" => $user->date_upd,
                "email"         => $user->email,
                "first_name"    => $user->firstname,
                "last_name"     => $user->lastname,
                "username"      => null,
                "last_order"    => array(
                    "id"   => "",
                    "date" => ""
                ),
                "orders_count"  => 0,
                "total_spent"   => "0.00",
                "avatar_url"    => "",
                "billing"       => array(
                    "first_name" => "",
                    "last_name"  => "",
                    "company"    => "",
                    "address_1"  => "",
                    "address_2"  => "",
                    "city"       => "",
                    "state"      => "",
                    "postcode"   => "",
                    "country"    => "",
                    "email"      => "",
                    "phone"      => ""
                ),
                "shipping"      => array(
                    "first_name" => "",
                    "last_name"  => "",
                    "company"    => "",
                    "address_1"  => "",
                    "address_2"  => "",
                    "city"       => "",
                    "state"      => "",
                    "postcode"   => "",
                    "country"    => ""
                ),
                "_links"        => array(
                    "self"       => array(
                        array(
                            "href" => $customerLink
                        )
                    ),
                    "collection" => array(
                        array(
                            "href" => ""
                        )
                    )
                ),
                "avatar"        => ""
            );
            return $return;
        }

        protected function _forgotPassword()
        {
            #submit email to get link change password
            if (!($email = trim(Tools::getValue('user_login'))) || !Validate::isEmail($email)) {
                throw new Exception(MessageIcy::USER_LOGIN_INVALID_EMAIL);
            }
            $customer = new Customer();
            $customer->getByemail($email);
            if (!Validate::isLoadedObject($customer)) {
                throw new Exception(MessageIcy::USER_FORGOT_USER_NOT_EXIST);
            } elseif (!$customer->active) {
                throw new Exception('You cannot regenerate the password for this account.');
            } elseif ((strtotime($customer->last_passwd_gen . '+' . ($min_time = (int) Configuration::get('PS_PASSWD_TIME_FRONT')) . ' minutes') - time()) > 0) {
                throw new Exception(sprintf(Tools::displayError('You can regenerate your password only every %d minute(s)'), (int) $min_time));
            } else {
                $mail_params = array (
                    '{email}'     => $customer->email,
                    '{lastname}'  => $customer->lastname,
                    '{firstname}' => $customer->firstname,
                    '{url}'       => $this->context->link->getPageLink('password', true, null, 'token=' . $customer->secure_key . '&id_customer=' . (int) $customer->id)
                );
                if (Mail::Send($this->context->language->id, 'password_query', Mail::l('Password query confirmation'), $mail_params, $customer->email, $customer->firstname . ' ' . $customer->lastname)) {
                    return 'true';
                } else {
                    throw new Exception('An error occurred while sending the email.');
                }
            }
        }

        protected function _updateCustomer()
        {
            $firstname = Tools::getValue('user_firstname');
            $lastname = Tools::getValue('user_lastname');
            $email = Tools::getValue('user_email');
            $passwd = Tools::getValue('user_pass');
            $newPasswd = Tools::getValue('user_new_password');
            $newPasswdConfirm = Tools::getValue('user_confirmation');
            $userId = intval(Tools::getValue('user_id'));
            
            if(!Customer::customerIdExistsStatic($userId)) {
                throw new Exception('User is not exist');
            }
            
            if(!empty($firstname) && !Validate::isName($firstname)) {
                throw new Exception('Invalid firstname');
            }
            
            if(!empty($lastname) && !Validate::isName($lastname)) {
                throw new Exception('Invalid lastname');
            }
            
            if(!empty($email) && !Validate::isEmail($email)) {
                throw new Exception('Invalid email');
            }
            
            if(empty($userId) || !is_integer($userId)) {
                throw new Exception('Please login to change personal infomations');
            }
            
            if(empty($passwd) && (!empty($newPasswd) || !empty($newPasswdConfirm)) ) {
                throw new Exception('Please type current password to change password');
            }
            
            if(!empty($passwd) && (empty($newPasswd) || empty($newPasswdConfirm)) ) {
                throw new Exception('Please fill in new password and re confirm new password to change personal infomations');
            }
            
            if(!empty($passwd) && ($newPasswd != $newPasswdConfirm) ) {
                throw new Exception('Please type correct new password and re confirm new password to change personal infomations');
            }
            if(!empty($passwd) && Customer::checkPassword($userId, Tools::encrypt($passwd)) == false ) {
                throw new Exception('wrong current password');
            }
            
            $currentUserObject = new Customer($userId);
            if(!empty($firstname)) 
            $currentUserObject->firstname = $firstname;
            if(!empty($lastname)) 
            $currentUserObject->lastname = $lastname;
            if(!empty($email)) 
            $currentUserObject->email = $email;
            if(!empty($newPasswd)) 
            $currentUserObject->passwd = Tools::encrypt($newPasswd);
            
            if(!$currentUserObject->update()) {
                throw new Exception('have something happen,can\'t change information at this time');
            }
            
            return true;
        }

        protected function _updateAddress($isBilling = true)
        {
            return array();
        }

    }
    