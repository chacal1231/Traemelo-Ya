<?php
/**
 * Copyright © 2016 Inspius. All rights reserved.
 * Author: Phong Nguyen
 * Author URI: http://inspius.com
 */

class Status extends ObjectModel
{
    const API_SUCCESS = 1;
    const API_FAILED = -1;
}