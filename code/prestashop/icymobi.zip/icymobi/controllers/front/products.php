<?php

    /**
     * Copyright © 2016 Inspius. All rights reserved.
     * Author: Khanh Tran
     * Author URI: http://inspius.com
     */
    require_once('api.php');

    class IcymobiProductsModuleFrontController extends AbstractIcymobiApiFrontController
    {

        const REQUEST_SINGLE = 'single';
        const REQUEST_CATEGORY = 'category';
        const REQUEST_TYPE = 'type';
        const REQUEST_SEARCH = 'search';
        const REQUEST_TAG = 'tag';

        protected $id_lang_default;
        protected $_productGroup = array('featured', 'onsale', 'best_seller', 'most_view', 'new');
        protected $_linkObj;

        public function __construct()
        {
            parent::__construct();
            $this->id_lang_default = Configuration::get('PS_LANG_DEFAULT');
        }

        protected function _getResponse()
        {
            $data = array();

            // request type. Use in switch
            $type = Tools::getValue('type');

            // main parameter
            $param = Tools::getValue('param');

            // params use in search product. Add ability to search by category
            $param2 = Tools::getValue('params2');

            // additional params
            // load order setting from admin panel
            $defaultOrder = 'id';
            $defaultOrderDir = 'desc';

            // other parameter
            $orderBy = Tools::getValue('orderby', $defaultOrder);

            if (!in_array($orderBy, array('date', 'id', 'name'))) {
                $orderBy = 'id';
            } else {
                switch ($orderBy) {
                    case 'date' :
                        $orderBy = 'date_add';
                        break;
                    case 'id' :
                        $orderBy = 'id_product';
                        break;
                    case 'name' :
                        $orderBy = 'name';
                        break;
                }
            }

            $order = Tools::getValue('order', $defaultOrderDir);
            if (!in_array($order, array('asc', 'desc'))) {
                $order = 'desc';
            }
            $page = Tools::getValue('page', 1);
            $perPage = Tools::getValue('per_page', 10);

            // get product by type
            switch ($type) {
                case self::REQUEST_TYPE:
                    if ($param && in_array(strtolower($param), $this->_productGroup)) {
                        $fn = '_get' . ucfirst(str_replace('_', '', $param));
                        $data = $this->$fn($page, $perPage, $orderBy, $order, $param2);
                    }
                    break;
                case self::REQUEST_SINGLE:
                    if ($param && is_numeric($param)) {
                        $data = $this->_getSingleProduct($param);
                    }
                    break;
                case self::REQUEST_CATEGORY:
                    if ($param && is_numeric($param)) {
                        $data = $this->_getCategoryProducts($param, $page, $perPage, $order, $orderBy);
                    }
                    break;
                case self::REQUEST_SEARCH:
                    if ($param) {
                        if ($param2) {
                            $category = $param2;
                        } else {
                            $category = null;
                        }
//                        $data = $category;break;
                        $data = $this->_searchProduct($param, $page, $perPage, $order, $orderBy, $category);
                    }
                    break;
                case self::REQUEST_TAG:
                    if ($param) {
                        $data = $this->_getProductWtTag($param, $page, $perPage, $orderBy, $order);
                    }
                    break;
                default:
                    $data = $this->_getAllProduct($page, $perPage, $orderBy, $order);
                    break;
            }

            return $data;
        }

        protected function _getSingleProduct($param)
        {
            return $this->_getOneProductForApi($param);
        }

        private function get_rating_html($star, $count = null)
        {
            $width = intval($star) * 20;
            return '
            <div class="rate">
                <span style="width: ' . $width . '%;"></span>
            </div>
            <span class="count">(' . $count . ')</span>
        ';
        }

        /**
         *  Get Single Product Info by id_product
         * 
         * @param int $id_product
         * @return array
         */
        private function _getOneProductForApi($id_product)
        {
            $product = new Product($id_product, '', $this->id_lang_default, Configuration::get('PS_SHOP_DEFAULT'));
            $rating = '';
            $rating_html = '';
            $rating_count = '';
            if(Module::isInstalled('productcomments') && Module::isEnabled('productcomments')) {
                if (file_exists(dirname(dirname(dirname(dirname(__FILE__)))) . '/productcomments/ProductComment.php')) {
                    include_once dirname(dirname(dirname(dirname(__FILE__)))) . '/productcomments/ProductComment.php';
                    $ratingDatas = ProductComment::getRatings($id_product);
                    if (!empty($ratingDatas)) {
                        $rating = ProductComment::getRatings($id_product)['avg'];
                        $rating_html = $this->get_rating_html($rating, $rating_count);
                        $rating_count = ProductComment::getGradedCommentNumber($id_product);
                    }
                }
            }

            $this->_linkObj = new Link();
            $variationAndAttribute = $this->_getAllVariationsOfProduct($product);
            $productReturn = array (
                "id"                  => $product->id,
                "name"                => $product->name,
                "slug"                => $product->link_rewrite,
                "array_categories_id" => $product->getCategories(),
                "permalink"           => _PS_BASE_URL_ . __PS_BASE_URI__ . 'module/icymobi/products?type=single&param=' . $product->id . '',
                "date_created"        => $product->date_add,
                "date_modified"       => $product->date_upd,
                "type"                => (count($variationAndAttribute['variations']) > 1) ? 'variable' : 'simple',
                "status"              => "",
                "featured"            => "",
                "catalog_visibility"  => ($product->visibility == 'both' || $product->visibility == 'catalog') ? 'visiable' : 'none',
                "description"         => ($product->description),
                "short_description"   => ($product->description_short),
                "sku"                 => "",
                "price"               => $product->getPrice(),
                "regular_price"       => $product->getPriceWithoutReduct(),
                "sale_price"          => $product->getPrice(),
                "date_on_sale_from"   => $product->available_date,
                "date_on_sale_to"     => "",
                "price_html"          => "",
                "on_sale"             => $this->isDisplayOnSale($product),
                "purchasable"         => true,
                "total_sales"         => $this->getTotalSalesOnProduct($product),
                "virtual"             => $product->is_virtual,
                "downloadable"        => "",
                "downloads"           => array(),
                "download_limit"      => "",
                "download_expiry"     => "",
                "download_type"       => "",
                "external_url"        => "",
                "button_text"         => "",
                "tax_status"          => "",
                "tax_class"           => "",
                "manage_stock"        => (bool) ($product->useAdvancedStockManagement()),
                "stock_quantity"      => StockAvailable::getQuantityAvailableByProduct($product->id),
                "in_stock"            => $this->isDisplayInStock($product),
                "backorders"          => $product->isAvailableWhenOutOfStock((int) $product->out_of_stock) ? 'yes' : 'no',
                "backorders_allowed"  => (bool) $product->isAvailableWhenOutOfStock((int) $product->out_of_stock),
                "backordered"         => (bool) $product->isAvailableWhenOutOfStock((int) $product->out_of_stock),
                "sold_individually"   => (bool) false,
                "weight"              => $product->weight,
                "dimensions"          => array(
                    "length" => $product->depth,
                    "width"  => $product->width,
                    "height" => $product->height
                ),
                "shipping_required"   => true,
                "shipping_taxable"    => true,
                "shipping_class"      => "",
                "shipping_class_id"   => "",
                "reviews_allowed"     => true,
                "average_rating"      => $rating,
                "rating_count"        => $rating_count,
                "rating_star_html"    => $rating_html,
                "related_ids"         => array(),
                "upsell_ids"          => array(),
                "cross_sell_ids"      => array(),
                "parent_id"           => "",
                "purchase_note"       => "",
                "categories"          => $this->handleArrayCategoriesForProduct($product->getProductCategoriesFull($product->id)),
                "tags"                => $product->tags[$this->id_lang_default],
                "images"              => $this->handleArrayImageForProduct($this->_linkObj, $product->getImages($this->id_lang_default), $product->id),
                "attributes"          => $variationAndAttribute['attr'],
                "default_attributes"  => array(),
                "variations"          => $variationAndAttribute['variations'],
                "grouped_products"    => array(),
                "menu_order"          => 0,
                "_links"              => array(
                    "self"       => array(
                        array(
                            "href" => _PS_BASE_URL_ . __PS_BASE_URI__ . 'module/icymobi/products?type=single&param=' . $product->id . '',
                        )
                    ),
                    "collection" => array(
                        array(
                            "href" => ""
                        )
                    )
                )
            );
            return $productReturn;
        }

        public function isDisplayInStock(Product $product, $id_product_attribute = null)
        {
            if ($product->active != 1) {
                return false;
            }
            if ($product->available_for_order == false) {
                return false;
            }
            if ($id_product_attribute) {
                if (StockAvailable::getQuantityAvailableByProduct(null, $id_product_attribute) <= 0) {
                    return false;
                } else {
                    return true;
                }
            }
            if (StockAvailable::getQuantityAvailableByProduct($product->id) <= 0) {
                return false;
            } elseif (Configuration::get('PS_STOCK_MANAGEMENT')) {
                return true;
            }
        }

        public function isDisplayOnSale(Product $product, $id_product_attribute = null)
        {
            $productPriceWithoutReduction = $product->getPriceWithoutReduct();

            if ($productPriceWithoutReduction <= 0) {
                return false;
            }
            $specificPrices = SpecificPrice::getByProductId($product->id);

            if (!$specificPrices) {
                return false;
            }
            #check for variations
            if ($id_product_attribute) {
                $specificPriceByCombination = SpecificPrice::getByProductId($product->id, $id_product_attribute);
                if (!$specificPriceByCombination) {
                    foreach ($specificPrices as $specificPrice) {
                        if ($specificPrice['id_product_attribute'] == 0 && $specificPrice['reduction'] != 0) {
                            return true;
                        }
                    }
                } else {
                    $specificPrices[] = $specificPriceByCombination;
                }
            }

            foreach ($specificPrices as $specificPrice) {
                if ($specificPrice['reduction'] != 0) {
                    return true;
                }
            }

            return false;
        }

        private function _getAllVariationsOfProduct(Product $product)
        {
            $arrayVariations = array();
            # all ids of Product's variations
            $ids = $product->getProductAttributesIds($product->id, Configuration::get('PS_SHOP_DEFAULT'));

            foreach ($ids as $id) {
                $arrayVariations[] = $this->_getDetailVariation($product->id, $id['id_product_attribute'], $this->id_lang_default);
            }
            # Attributes get form all $allVariations
            $attributes = array();
            $arrayRawAttr = array();
            # array Attributes use to this Product's variations
            $arrayFormatAttr = array();

            if (count($arrayVariations) > 1) {
                foreach ($arrayVariations as $r1) {
                    $attributes[] = $r1['attributes'];
                }
                # Flat array $attributes
                $allAttrTmp = call_user_func_array('array_merge', $attributes);
                # Clean array $result unique
                foreach ($allAttrTmp as $aat) {
                    foreach ($arrayRawAttr as $r1) {
                        if ($r1['id_attribute'] == $aat['id_attribute']) {
                            continue 2;
                        }
                    }
                    $arrayRawAttr[] = $aat;
                }
                # All attrribute in setting
                $allSetAttr = $this->getAllAttributeOfProduct();
                foreach ($allSetAttr as $key => $attr) {
                    foreach ($arrayRawAttr as $r) {
                        if ($attr['id_attribute_group'] == $r['id_attribute_group']) {
                            $arrayFormatAttr[$key]['id'] = $attr['id_attribute_group'];
                            $arrayFormatAttr[$key]['name'] = $attr['group_name'];
                            $arrayFormatAttr[$key]['position'] = $attr['position'];
                            $arrayFormatAttr[$key]['visible'] = '';
                            $arrayFormatAttr[$key]['type'] = 'dropdown';
                            $arrayFormatAttr[$key]['options'][] = array(
                                'name'  => $r['option'],
                                'value' => $r['option']
                            );
                            $arrayFormatAttr[$key]['variation'] = (is_array($arrayFormatAttr[$key]['options']) && count($arrayFormatAttr[$key]['options'] > 0)) ? true : false;
                        }
                    }
                }
                # reset key 
                $arrayFormatAttr = array_values($arrayFormatAttr);
            }

            $this->formatArrayVariationsByRefenrence($arrayVariations);

            $CombinationAndAttr = array(
                'variations' => $arrayVariations,
                'attr'       => $arrayFormatAttr
            );
            return $CombinationAndAttr;
        }

        public function formatArrayVariationsByRefenrence(&$arrayVariations)
        {
            foreach ($arrayVariations as &$var) {
                $productObject = new Product($var['id_product']);
                $var['id'] = (int) $var['id_product_attribute'];
                $var['permalink'] = '';
                $var['sku'] = '';
                $var['regular_price'] = intval(($var['price']) ? : 0);
                $var['sale_price'] = intval(($var['price']) ? : 0);
                $var['date_on_sale_from'] = '';
                $var['date_on_sale_to'] = '';
                $var['on_sale'] = $this->isDisplayOnSale($productObject, $var['id_product_attribute']);
                $var['purchasable'] = true;
                $var['visible'] = '';
                $var['virtual'] = '';
                $var['downloadable'] = '';
                $var['downloads'] = '';
                $var['download_limit'] = '';
                $var['download_expiry'] = '';
                $var['tax_status'] = '';
                $var['tax_class'] = '';
                $var['manage_stock'] = '';
                $var['in_stock'] = $this->isDisplayInStock($productObject, $var['id_product_attribute']);
                $var['stock_quantity'] = ($var['quantity'] > 0) ? true : false;
                $var['backorders'] = $productObject->isAvailableWhenOutOfStock((int) $productObject->out_of_stock) ? 'yes' : 'no';
                $var['backorders_allowed'] = (bool) $productObject->isAvailableWhenOutOfStock((int) $productObject->out_of_stock);
                $var['backordered'] = $productObject->isAvailableWhenOutOfStock((int) $productObject->out_of_stock);
                $var['weight'] = $var['weight'];
                $var['dimensions'] = array(
                    "length" => '',
                    "width"  => '',
                    "height" => ''
                );
                $var['shipping_class'] = '';
                $var['shipping_class_id'] = '';
                unset($var['id_product_attribute']);
                unset($var['quantity']);
                unset($var['weight']);
            }
        }

        /**
         * Get detail Variation by id_product_attribute (variation ID)
         * 
         * @param int $id_product
         * @param int $id_product_attribute
         * @param int $id_lang
         * @return array
         */
        private function _getDetailVariation($id_product, $id_product_attribute, $id_lang)
        {
            $rawVar = $this->getRawVariationById($id_product, $id_product_attribute, $id_lang);

            $attribute = array();
            //Get quantity of each variations
            foreach ($rawVar as $row) {
                foreach ($attribute as $value) {
                    if ($value['id_attribute'] == $row['id_attribute']) {
                        continue 2;
                    }
                }
                $attribute[] = array(
                    'id_attribute'       => $row['id_attribute'],
                    'name'               => $row['group_name'],
                    'option'             => $row['attribute_name'],
                    'id_attribute_group' => $row['id_attribute_group'],
                    'is_color_group'     => $row['is_color_group'],
                    'attribute_name'     => $row['attribute_name']
                );
            }
            $rawVar[0]['image'] = $this->_handleImageForCombiantion($rawVar[0]['id_product_attribute']);
            $rawVar[0]['attributes'] = $attribute;
            return $rawVar[0];
        }

        /**
         * Get array full info Images of Variations
         * @param int $id_product_attribute
         * @return string
         */
        private function _handleImageForCombiantion($id_product_attribute)
        {
            $rawArrayImages = $this->getImagesOfVariation($id_product_attribute);

            $allImagesOfVariation = array();
            if (!empty($rawArrayImages)) {
                foreach ($rawArrayImages as $row) {
                    $allImagesOfVariation[] = array(
                        "id"            => $row['id_image'],
                        "date_created"  => "",
                        "date_modified" => "",
                        "src"           => 'http://' . $this->_linkObj->getImageLink($id_product_attribute, $row['id_image']),
                        "name"          => "",
                        "alt"           => "",
                        "position"      => $row['position']
                    );
                }
            }
            return $allImagesOfVariation;
        }

        public function getTotalSalesOnProduct(Product $product)
        {
            return '';
        }

        /**
         *  Get array Images with full info
         * 
         * @param Link $link 
         * @param array $arrayImages
         * @param int $id_product
         * @return array
         */
        protected function handleArrayImageForProduct($link, $arrayImages, $id_product)
        {
            foreach ($arrayImages as &$image) {
                $image['id'] = $image['id_image'];
                $image['date_created'] = '';
                $image['date_modified'] = '';
                $image['src'] = 'http://' . $link->getImageLink($id_product, $image['id_image']);
                $image['alt'] = "";
                unset($image['id_image']);
                unset($image['cover']);
                unset($image['legend']);
            }
            return $arrayImages;
        }

        protected function handleArrayCategoriesForProduct($arrayCategories)
        {
            foreach ($arrayCategories as &$cate) {
                $cate['id'] = $cate['id_category'];
                $cate['slug'] = $cate['link_rewrite'];
                unset($cate['id_category']);
            }
            return $arrayCategories;
        }

        /**
         * Get all product by id_category
         * 
         * @param type $category_id
         * @param type $order
         * @param type $orderBy
         * @return type
         */
        protected function _getCategoryProducts($category_id, $page = null, $per_page = null, $order = 'desc', $orderBy = null)
        {
            if ($page < 1) {
                $page = 1;
            }
            if ($per_page < 1) {
                $per_page = 1;
            }


            $categoryObject = new Category($category_id, $this->id_lang_default);
            $productsData = $categoryObject->getProducts($this->id_lang_default, (int) $page, (int) $per_page, $orderBy, $order);

            $products = array();
            if (is_array($productsData) && !empty($productsData)) {
                foreach ($productsData as $product) {
                    $products[] = $this->_getOneProductForApi(intval($product['id_product']));
                }
            }
            return $products;
        }

        /**
         * Get All product for you
         * 
         * @param int $page
         * @param int $perPage
         * @param str $orderBy
         * @param str $order
         * @return array
         */
        protected function _getAllProduct($page, $perPage, $orderBy, $order)
        {
            if (!$page || $page < 1) {
                $page = 1;
            }
            if (!$perPage || $perPage < 1) {
                $perPage = 10;
            }
            $start = ($page - 1) * $perPage;
            if (!$orderBy) {
                $orderBy = 'id';
            }
            if (!$order) {
                $order = 'asc';
            }

            $productsData = Product::getProducts($this->id_lang_default, $start, $perPage, $orderBy, $order);

            $products = array();
            if (is_array($productsData) && !empty($productsData)) {
                foreach ($productsData as $product) {
                    $products[] = $this->_getOneProductForApi($product['id_product']);
                }
            }
            return $products;
        }

        /**
         * 
         * @param string $param
         * @param int $page
         * @param int $perPage
         * @param string $order
         * @param string $orderBy
         * @return array
         */
        protected function _searchProduct($param, $page, $perPage, $order, $orderBy, $id_category = null)
        {
            if ($orderBy) {
                $orderBy = 'p.' . $orderBy;
            }
            $products = array();

            $productsData = Search::find($this->id_lang_default, $param, $page, $perPage, $orderBy, $order, $ajax = false, $use_cookie = false, $context = null);

            if ($productsData['result'] && !empty($productsData['result'])) {
                foreach ($productsData['result'] as $product) {
                    $products[] = $this->_getOneProductForApi($product['id_product']);
                }
            }
            if ($id_category && Validate::isLoadedObject($categoryObject = new Category($id_category))) {
                $resultByCate = array();
                foreach ($products as $key => $product) {
                    if (!in_array($id_category, $product['array_categories_id'])) {
//                        unset($products[$key]);
                        $resultByCate[] = $products[$key];
                    }
                }
                return $resultByCate;
            }
            return $products;
        }

        /**
         * 
         * @param type $param
         * @param type $page
         * @param type $perPage
         * @param type $orderBy
         * @param type $order
         * @return type
         */
        private function _getProductWtTag($param, $page, $perPage, $orderBy, $order)
        {
            if ($orderBy) {
                $orderBy = 'p.' . $orderBy;
            }
            $productsData = Search::searchTag($this->id_lang_default, $param, $count = false, $page, $perPage, $orderBy, $order, $useCookie = false, $context = null);

            $products = array();
            if (is_array($productsData) && !empty($productsData)) {
                foreach ($productsData as $product) {
                    $products[] = $this->_getOneProductForApi($product['id_product']);
                }
            }
            return $products;
        }

        #  
        #  ----- for Type 
        #  

        protected function _getFeatured()
        {
            
        }

        protected function _getOnsale()
        {
            
        }

        protected function _getBestseller($page, $per_page, $orderBy, $order)
        {
            if ($orderBy && !empty($orderBy)) {
                $orderBy = 'p.' . $orderBy;
            }
            $productsData = ProductSale::getBestSales($this->id_lang_default, $page, $per_page, $orderBy, $order);

            $products = array();

            if (!empty($productsData) && is_array($productsData)) {
                foreach ($productsData as $product) {
                    $products[] = $this->_getOneProductForApi($product['id_product']);
                }
            }
            return $products;
        }

        protected function _getMostview()
        {
            
        }

        protected function _getNew($page, $perPage, $orderBy, $order)
        {
            if ($orderBy !== '') {
                $orderBy = 'p.' . $orderBy;
            }
            $productsData = Product::getNewProducts($this->id_lang_default, $page, $perPage, $count = false, $orderBy, $order, $context = null);
            $products = array();
            if (!empty($productsData) && is_array($productsData)) {
                foreach ($productsData as $product) {
                    $products[] = $this->_getOneProductForApi($product['id_product']);
                }
            }
            return $products;
        }

        public function getAllAttributeOfProduct()
        {
            return Db::getInstance()->executeS('SELECT a.id_attribute_group, a.position, al.name as group_name '
                            . ' FROM ' . _DB_PREFIX_ . 'attribute_group a '
                            . ' LEFT JOIN ' . _DB_PREFIX_ . 'attribute_group_lang al ON a.id_attribute_group = al.id_attribute_group '
                            . ' WHERE al.id_lang = ' . $this->id_lang_default . ' ');
        }

        /**
         * Query product attribute combination by id_product_attribute
         *
         * @param int $id_product_attribute
         * @param int $id_lang Language id
         * @return array Product attribute combination by id_product_attribute
         */
        public function getRawVariationById($id_product, $id_product_attribute, $id_lang)
        {
            $productObject = new Product($id_product, '', $this->id_lang_default);
            $combinationsData = $productObject->getAttributeCombinationsById($id_product_attribute, $id_lang);

            if (!empty($combinationsData)) {
                foreach ($combinationsData as &$combination) {
                    $combination['price'] = Product::getPriceStatic($id_product, $usetax = true, $id_product_attribute);
                }
            }

            return $combinationsData;
        }

        public function getImagesOfVariation($id_product_attribute)
        {
            $rawArrayImages = Db::getInstance()->executeS('
			SELECT pai.`id_image`, pai.`id_product_attribute`, il.`legend`, i.position
			FROM `' . _DB_PREFIX_ . 'product_attribute_image` pai
			LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il ON (il.`id_image` = pai.`id_image`)
			LEFT JOIN `' . _DB_PREFIX_ . 'image` i ON (i.`id_image` = pai.`id_image`)
			WHERE pai.`id_product_attribute` = ' . $id_product_attribute . ' AND il.`id_lang` = ' . (int) $this->id_lang_default . ' ORDER by i.`position`'
            );
            if (!$rawArrayImages) {
                return array();
            }
            return $rawArrayImages;
        }

    }
    