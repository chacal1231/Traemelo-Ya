<?php

    /**
     * Copyright © 2016 Inspius. All rights reserved.
     * Author: Khanh Tran
     * Author URI: http://inspius.com
     */
    require_once("api.php");
    require_once('helpers/Setting.php');

    class IcymobiSettingsModuleFrontController extends AbstractIcymobiApiFrontController
    {

        protected function _getResponse()
        {
            $token = Tools::getValue('token', null);
            $this->updateDeviceToken($token);

            $currentcy_format = array (
                array ('key' => 1, 'name' => 'X0,000.00', 'separator_thousand' => ',', 'separator_decimal' => '.', 'sample' => '10,000.99', 'sample_html' => 'sign10,000.99'),
                array ('key' => 2, 'name' => '0 000,00X', 'separator_thousand' => ' ', 'separator_decimal' => ',', 'sample' => '10 000,99', 'sample_html' => '10 000,99sign'),
                array ('key' => 3, 'name' => 'X0.000,00', 'separator_thousand' => '.', 'separator_decimal' => ',', 'sample' => '10.000,99', 'sample_html' => 'sign10.000,99'),
                array ('key' => 4, 'name' => '0,000.00X', 'separator_thousand' => ',', 'separator_decimal' => '.', 'sample' => '10,000.99', 'sample_html' => '10,000.99sign'),
                array ('key' => 5, 'name' => '0\'000.00X', 'separator_thousand' => '\'', 'separator_decimal' => '.', 'sample' => '10\'000.99', 'sample_html' => '10\'000.99sign')
            );

            $settings = new IcymobiSetting();

            $currencyDefaultObject = Currency::getDefaultCurrency();
            $version = Configuration::get('PS_INSTALL_VERSION');
            $currencyFormat = $currencyDefaultObject->format;
            if(version_compare($version, '1.7.0.0') >= 0) {
				$samplePriceHtml = Tools::displayPrice(10000.99);
				preg_match("/(\d){2}([,.']){1}(\d){3}([,.']){1}(\d){2}/", $samplePriceHtml, $match);
				$samplePrice = $match[0];
				$decimal_separator = $match[4];
				$thousand_separator = $match[2];
            } else {
				foreach ($currentcy_format as $value) {
					if ($currencyFormat == $value['key']) {
						$thousand_separator = $value['separator_thousand'];
						$decimal_separator = $value['separator_decimal'];
						$samplePrice = $value['sample'];
						$samplePriceHtml = str_replace('sign', $currencyDefaultObject->sign, $value['sample_html']);
						break;
					}
				}
			}

            $data = array(
                "thousand_separator"  => $thousand_separator,
                "decimal_separator"   => $decimal_separator,
                "number_decimals"     => 2,
                "samplePrice"         => $samplePrice,
                "samplePriceHtml"     => $samplePriceHtml,
                "contact_map_lat"     => Configuration::get('CONTACT_MAP_LAT'),
                "contact_map_lng"     => Configuration::get('CONTACT_MAP_LONG'),
                "contact_map_title"   => Configuration::get('CONTACT_MAP_TITLE'),
                "contact_map_content" => Configuration::get('CONTACT_MAP_CONTENT'),
                "disable_app"         => Configuration::get('GENERAL_ENABLE_APP'),
                "disable_app_message" => Configuration::get('GENERAL_MAINTENANCE_TEXT'),
                "category_display"    => Configuration::get('GENERAL_CATEGORY_DISPLAY'),
                "contact_email"       => Configuration::get('CONTACT_EMAIL'),
                "contact_phone"       => Configuration::get('CONTACT_PHONE'),
                "blog_display"        => 'posts',
            );
            $settings->addElements($data);

            Hook::exec(
                    'actionIcymobiSettings', array ('settings' => $settings), null, true
            );

            return $settings->getSettings();
        }

        public function updateDeviceToken($deviceToken)
        {
            if ($deviceToken != null) {
                $rawDeviceToken = Configuration::get('ICYMOBI_DEVICE_TOKEN');
                $arrayDeviceToken = json_decode($rawDeviceToken);

                if (empty($arrayDeviceToken)) {
                    $arrayDeviceToken = array ();
                }
                if (!in_array($deviceToken, $arrayDeviceToken)) {
                    $arrayDeviceToken[] = $deviceToken;
                }
                Configuration::updateValue('ICYMOBI_DEVICE_TOKEN', json_encode($arrayDeviceToken));
            }
        }

    }