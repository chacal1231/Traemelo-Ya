<?php

    /**
     * Copyright © 2016 Inspius. All rights reserved.
     * Author: Khanh Tran
     * Author URI: http://inspius.com
     */
    require_once('api.php');
    require_once('helpers/Data.php');

    class IcymobiBlogsModuleFrontController extends AbstractIcymobiApiFrontController
    {

        const REQUEST_SINGLE = 'single';
        const REQUEST_SEARCH = 'search';
        const REQUEST_CATEGORY = 'category';
        const REQUEST_TAG = 'tag';
        const ADD_NEW_COMMENT = 'add';
        const REQUEST_GET_CATEGORY = 'get_category';

        public $id_lang_default;

        public function __construct()
        {
            parent::__construct();
            $this->id_lang_default = Configuration::get('PS_LANG_DEFAULT');
        }

        protected function _getResponse()
        {
            $data = array();
            $type = Tools::getValue('type');
            $param = Tools::getValue('param');
            $isSingle = false;

            // get product by type
            switch ($type) {
                case self::REQUEST_SINGLE:
                    if ($param) {
                        $data['p'] = (int)$param;
                        $isSingle = true;
                    }
                    break;
                case self::REQUEST_CATEGORY:
                    if ($param) {
                        $data['cat'] = $param;
                    }
                    break;
                case self::REQUEST_SEARCH:
                    if ($param) {
                        $data['s'] = $param;
                    }
                    break;
                case self::REQUEST_TAG:
                    if ($param) {
                        $data['tag'] = $param;
                    }
                    break;
//                case self::ADD_NEW_COMMENT:
//                    if ($param) {
//                        $this->_addNewComment($param);
//                        return null;
//                    } else {
//                        throw new Exception(Inspius_Status::COMMENT_ADD_NEW_FAILED);
//                    }
//                case self::REQUEST_GET_CATEGORY:
//                    return $this->_getCategoryList();
                default:
                    break;
            }

            if (Tools::getValue('page')) {
                $data['paged'] = (int)Tools::getValue('page');
            }
            if (Tools::getValue('per_page')) {
                $data['posts_per_page'] = (int)Tools::getValue('per_page');
            }
            
            $blogs = $this->getBlog($data);
            return ($blogs);
        }
        
        public function getBlog($data)
        {
            $singleFlag = false;
            if( isset($data['p']) && $data['p'] > 0) {
                $singleFlag = true;
            }
            if(isset($data['paged']) && isset($data['posts_per_page'])) {
                $offset = ($data['paged'] - 1) * $data['posts_per_page'];
            }
            $cmsRaw = CMSCore::getLinks($this->id_lang_default);
            if(isset($offset) && (count($cmsRaw) <= $offset)) {
                return array();
            }
            $shopName = Configuration::get('PS_SHOP_NAME');
            foreach ($cmsRaw as $key => &$cms) {
                if($singleFlag) {
                    if($data['p'] != $cms['id_cms']) {
                        unset($cmsRaw[$key]);
                        continue;
                    }
                }
                $cms['id'] = $cms['id_cms'];
                $cms['post_author'] = $shopName;
                $cms['post_content'] = str_replace('src="..','src="'._PS_BASE_URL_.__PS_BASE_URI__,CMSCore::getCMSContent($cms['id_cms'])['content']);
                $cms['post_title'] = $cms['meta_title'];
                $cms['post_excerpt'] = strip_tags(substr($cms['post_content'], 0, strpos($cms['post_content'], '.',50)+1)).((strlen($cms['post_content']) > 50)?'..':'');
                $cms['post_link'] = $cms['link'];
                $cms['post_date'] = 'N/A';
                $cms['post_tags'] = $this->formatTags();
                $cms['post_categories'] = array();
                $cms['post_comment'] = array();
                unset($cms['id_cms']);
                unset($cms['link_rewrite']);
                unset($cms['meta_title']);
                unset($cms['link']);
                unset($cms['link_rewrite']);
            }
            return array_values($cmsRaw);
        }
        
        public function formatTags()
        {
            return array();
        }
    }