<?php

    /**
     * Copyright © 2016 Inspius. All rights reserved.
     * Author: Khanh Tran
     * Author URI: http://inspius.com
     */
    require_once('api.php');
    require_once('helpers/Data.php');
    
    class FreeOrder extends PaymentModule
    {

        public $active = 1;
        public $name = 'free_order';
        public $displayName = 'free_order';

    }

    class IcymobiOrdersModuleFrontController extends AbstractIcymobiApiFrontController
    {

        const REQUEST_CREATE_CART = 'create_cart';
        const REQUEST_GET_PRICE = 'get_price';
        const REQUEST_CREATE_ORDER = 'create_order';
        const REQUEST_GET_ORDER = 'get_order';
        const REQUEST_LIST_CUSTOMER_ORDER = 'list_customer_order';
        const REQUEST_LIST_COUNTRIES = 'list_countries';
        const REQUEST_CHANGE_ORDER_STATUS = 'change_order_status';

        public $id_lang_default;

        public function __construct()
        {
            parent::__construct();
            $this->id_lang_default = Configuration::get('PS_LANG_DEFAULT');
        }

        protected function _getResponse()
        {
            $task = Tools::getValue('task');

            // main parameter
            $param = Tools::getValue('param');

            // other parameter
            // get product by type
            switch ($task) {
                case self::REQUEST_CREATE_CART:
                    if (!Tools::getValue('line_items') || !Tools::getValue('billing') || !Tools::getValue('shipping')) {
                        throw new Exception('Invalid parameters');
                    }
                    return $this->createCart();
                case self::REQUEST_GET_PRICE:
                    if (!Tools::getValue('line_items') || !Tools::getValue('cart_id')) {
                        throw new Exception('Invalid parameters');
                    }
                    $data = $this->getPrice(Tools::getValue('cart_id'), Tools::getValue('coupon'));
                    break;
                case self::REQUEST_CREATE_ORDER:
                    if (!Tools::getValue('line_items') || !Tools::getValue('billing') || !Tools::getValue('shipping') || !Tools::getValue('payment_method') || !Tools::getValue('payment_method_title') || !Tools::getValue('shipping_lines')
                    ) {
                        throw new Exception('Invalid parameters');
                    }
                    $data = $this->createOrder();
                    break;
                case self::REQUEST_CHANGE_ORDER_STATUS:
                    if (!Tools::getValue('id') || !Tools::getValue('status')) {
                        throw new Exception('Invalid parameters');
                    }
                    $data = $this->changeOrderStatus();
                    break;
                case self::REQUEST_LIST_CUSTOMER_ORDER:
                    $customer_id = intval(Tools::getValue('customer_id'));
                    if (!$customer_id) {
                        throw new Exception('Invalid Parameter');
                    }
                    $data = $this->getListCustomerOrder($customer_id);
                    break;
                case self::REQUEST_LIST_COUNTRIES:
                    $data = $this->_getCountryList($param);
                    break;
                default:
                    $dataObject = new IcymobiData();
                    Hook::exec(
                            'actionIcymobi'.$task, 
                            array(
                            'OrderObject' => $this,
                            'DataObject' => $dataObject
                            ), 
                            null, 
                            true
                    );
                    $data = $dataObject->getData();
                    break;
            }
            return $data;
        }

        public function _getCountryList()
        {
            if (Configuration::get('PS_RESTRICT_DELIVERED_COUNTRIES')) {
                $arrayCountries = Carrier::getDeliveredCountries($this->id_lang_default, true, true);
            } else {
                $arrayCountries = Country::getCountries($this->id_lang_default, true);
            }

            foreach ($arrayCountries as &$country) {
                $country['id'] = $country['iso_code'];
                $country['state'] = array();
                if ($country['contains_states'] == 1) {
                    foreach ($country['states'] as $state) {
                        $country['state'][$state['iso_code']] = $state['name'];
                    }
                }
                unset($country['id_country']);
                unset($country['states']);
                unset($country['id_lang']);
                unset($country['id_zone']);
                unset($country['iso_code']);
                unset($country['id_currency']);
                unset($country['call_prefix']);
                unset($country['active']);
                unset($country['contains_states']);
                unset($country['need_identification_number']);
                unset($country['need_zip_code']);
                unset($country['zip_code_format']);
                unset($country['display_tax_label']);
                unset($country['country']);
                unset($country['zone']);
            }
            return ($arrayCountries);
        }

        public function getPrice($id_cart, $coupon = null)
        {
            $cartObject = new Cart($id_cart);
            $currency = Currency::getCurrency($cartObject->id_currency);
            if ($coupon) {
                $id_cart_rule = CartRule::getIdByCode($coupon);
                $cartObject->addCartRule($id_cart_rule);
            }
            $detailCart = $cartObject->getSummaryDetails();
            return array(
                'currency'       => $currency['iso_code'],
                'discount_total' => (float) $detailCart['total_discounts'],
                'subtotal'       => (float) $detailCart['total_products'],
                'total'          => (float) $detailCart['total_price'] - $detailCart['total_shipping'],
            );
        }

        public function createCart()
        {
            $billing = json_decode(str_replace("\\", "", Tools::getValue('billing')), true);
            $shipping = json_decode(str_replace("\\", "", Tools::getValue('shipping')), true);
            $line_items = json_decode(str_replace("\\", "", Tools::getValue('line_items')), true);
            $customerId = Tools::getValue('customer_id');
            $coupon = Tools::getValue('coupon');

            $cartObject = $this->createCartObjectAndSave($billing, $shipping, $line_items, $customerId, $coupon);

            $shippingRawMethod = $cartObject->getDeliveryOptionList();
            $shippingMethod = $this->formatShippingMethod($shippingRawMethod);
            $paymentMethod = $this->getPaymentMethod();

            $data = array(
                'cart_id'          => $cartObject->id,
                'price'            => $this->getPrice($cartObject->id),
                'shipping_methods' => $shippingMethod,
                'payment_methods'  => $paymentMethod
            );
            return $data;
        }

        public function formatShippingMethod($shippingMethod)
        {
            $arrayShipping = array();
            foreach ($shippingMethod as $carrierListId) {
                foreach ($carrierListId as $id_payment => $carrierList) {
                    foreach ($carrierList as $carrier) {
                        if (!is_array($carrier)) {
                            continue;
                        }
                        foreach ($carrier as $ca) {
                            $r = array();
                            array(
                                $r['cost'] = $ca['price_with_tax'],
                                $r['availability'] = $ca['instance']->active,
                                $r['countries'] = array(),
                                $r['enabled'] = ($ca['instance']->active == 1) ? 'yes' : 'no',
                                $r['errors'] = array(),
                                $r['fee'] = null,
                                $r['form_fields'] = array(),
                                $r['has_settings'] = true,
                                $r['id'] = (int) $ca['instance']->id,
                                $r['instance_form_fields'] = array(
                            'min_amount' => array(
                                'default'     => "0",
                                'desc_tip'    => true,
                                'description' => "",
                                'placeholder' => "",
                                'title'       => "",
                                'type'        => ""
                            ),
                            'title'      => array(
                                'title' => "Title",
                                'type'  => "text"
                            ),
                            'requires'   => array(
                                'class'   => "",
                                'default' => ""
                            ),
                                ),
                                $r['instance_id'] = $ca['instance']->id,
                                $r['instance_settings'] = array(
                            'title'      => "",
                            'requires'   => "",
                            'min_amount' => "0"
                                ),
                                $r['method_description'] = "",
                                $r['method_order'] = 1,
                                $r['method_title'] = "",
                                $r['min_amount'] = "0",
                                $r['minimum_fee'] = null,
                                $r['plugin_id'] = "",
                                $r['rates'] = array(),
                                $r['requires'] = "",
                                $r['settings'] = array(),
                                $r['settings_html'] = '',
                                $r['supports'] = array(),
                                $r['tax_status'] = "",
                                $r['title'] = $ca['instance']->name
                            );
                            $arrayShipping[str_replace(', ', '', $id_payment)] = $r;
                        }
                    }
                }
            }
            $return = array(
                'default' => array(
                    'meta_data'        => array(),
                    'zone_id'          => 0,
                    'zone_locations'   => array(),
                    'zone_name'        => '',
                    'zone_order'       => '',
                    'shipping_methods' => $arrayShipping
                ),
                'zones'   => array()
            );
            return $return;
        }

        public function getPaymentMethod()
        {
            $arrayPaymentMethod = PaymentModule::getInstalledPaymentModules();
            $paymentDatas = array();
            foreach ($arrayPaymentMethod as $payment) {
                if ($payment['name'] == 'bankwire' || $payment['name'] == 'cheque') {
                    $payModObj = Module::getInstanceByName($payment['name']);
                    if ($payment['name'] == 'bankwire') {
                        $payment['accounts'][] = array(
                            'owner'   => $payModObj->owner,
                            'details' => $payModObj->details,
                            'address' => $payModObj->address
                        );
                    }
                    $payment['title'] = $payModObj->displayName;
                    $payment['description'] = $payModObj->description;
                    $payment['id'] = $payment['name'];
                    unset($payment['name']);
                    unset($payment['id_module']);
                    unset($payment['id_hook']);
                    unset($payment['position']);

                    $paymentDatas[$payment['id']] = $payment;
                }
            }
            
            $dataObject = new IcymobiData();
            $dataObject->addElements($paymentDatas);
            
            Hook::exec('actionPaymentIcymobiGateway', array('paymentDatas' => $dataObject), null, true);
            
            return $dataObject->getData();
        }

        /**
         * 
         * @param type $billing
         * @param type $shipping
         * @param type $line_items
         * @param type $customerId
         * @param type $coupon
         * @return \Cart
         */
        public function createCartObjectAndSave($billing, $shipping, $line_items, $customerId, $coupon, $id_carrier = null)
        {
            if ($customerId && Validate::isInt($customerId)) {
                if (!Customer::customerIdExistsStatic($customerId)) {
                    $customerId = null;
                }
            }

            $deliveryAddress = $this->createNewAddressObject($shipping);

            $invoiceAddress = $deliveryAddress;

            if ($billing !== $shipping) {
                $invoiceAddress = $this->createNewAddressObject($billing);
            }

            $cartObject = new Cart();
            $cartObject->id_address_delivery = $deliveryAddress->id;
            $cartObject->id_address_invoice = $invoiceAddress->id;
            $cartObject->id_customer = $customerId;
            $cartObject->id_currency = Configuration::get('PS_CURRENCY_DEFAULT');
            if ($id_carrier && Validate::isLoadedObject($CarrierObject = new Carrier($id_carrier))) {

                $cartObject->id_carrier = $CarrierObject->id;

                # set right format if check with ParentOrderController->validateDeliveryOption()
                $cartObject->setDeliveryOption(array($cartObject->id_address_delivery => $CarrierObject->id . ','));
            }

            $cartObject->save();

            foreach ($line_items as $item) {
                if (!$item['product_id'] || !$item['quantity'])
                    return array('This product is no longer avaiable');

                $product = new Product($item['product_id'], true, $this->id_lang_default);

                # check product avaiable
                if (!$product->active) {
                    return array('This product is no longer avaiable');
                }
                if ($customerId != null && !$product->checkAccess($customerId)) {
                    return array('This product is no longer avaiable');
                }

                # check quantity 
                if (isset($item['variation_id'])) {
                    if (!Product::isAvailableWhenOutOfStock($product->out_of_stock) && !Attribute::checkAttributeQty($item['variation_id'], $item['quantity'])) {
                        return array('There isn\'t enough product in stock.');
                    }
                    $id_product_attribute = $item['variation_id'];
                } elseif ($product->hasAttributes()) {
                    $minimumQuantity = ($product->out_of_stock == 2) ? !Configuration::get('PS_ORDER_OUT_OF_STOCK') : !$product->out_of_stock;
                    $id_product_attribute = Product::getDefaultAttribute($product->id, $minimumQuantity);
                    // @todo do something better than a redirect admin !!
                    if (!$id_product_attribute) {
                        return array('This product is no longer avaiable');
                    } elseif (!Product::isAvailableWhenOutOfStock($product->out_of_stock) && !Attribute::checkAttributeQty($id_product_attribute, $item['quantity'])) {
                        return array('There isn\'t enough product in stock.');
                    }
                } elseif (!$product->checkQty($item['quantity'])) {
                    return array('There isn\'t enough product in stock.');
                }
                if (!$id_product_attribute) {
                    $id_product_attribute = $product->getDefaultIdProductAttribute();
                }
                # Check customizable fields
                if (!$product->hasAllRequiredCustomizableFields()) {
                    return array('Please fill in all of the required fields, and then save your customizations.');
                }

                # add product in to cart
                $update_quantity = $cartObject->updateQty($item['quantity'], $product->id, $id_product_attribute, false, 'up', 0);
                if ($update_quantity < 0) {
                    // If product has attribute, minimal quantity is set with minimal quantity of attribute
                    $minimal_quantity = ($id_product_attribute) ? Attribute::getAttributeMinimalQty($id_product_attribute) : $product->minimal_quantity;
                    return sprintf(Tools::displayError('You must add %d minimum quantity'), $minimal_quantity);
                } elseif (!$update_quantity) {
                    return Tools::displayError('You already have the maximum quantity available for this product.');
                }
            }
            if ($coupon) {
                $cartRule = new CartRule(CartRule::getIdByCode($coupon));
                if (Validate::isLoadedObject($cartRule) == false) {
                    throw new Exception('in valid voucher code ');
                }
                $context = Context::getContext();
                $context->cart = $cartObject;
                if ($displayError = $cartRule->checkValidity($context, false, true, false)) {
                    throw new Exception($displayError);
                }
                $cartObject->addCartRule($cartRule->id);
            }
            return $cartObject;
        }

        public function createOrder()
        {
            $billing = json_decode(str_replace("\\", "", Tools::getValue('billing')), true);
            $shipping = json_decode(str_replace("\\", "", Tools::getValue('shipping')), true);
            $line_items = json_decode(str_replace("\\", "", Tools::getValue('line_items')), true);
            $shipping_line = json_decode(str_replace("\\", "", Tools::getValue('shipping_lines')), true);
            $paymentMethod = Tools::getValue('payment_method');
            $paymentMethodTitle = Tools::getValue('payment_method_title');
            $paymentMethodData = Tools::getValue('payment_method_data');
            $customerId = intval(Tools::getValue('customer_id'));
            $coupon = Tools::getValue('coupon');
            $deviceToken = Tools::getValue('device_token');

            if (!$customerId) {
                # check setting mode guest enable 
                if (Configuration::get('PS_GUEST_CHECKOUT_ENABLED') == 1) {
                    $customerId = $this->createAccountForGuest($billing);
                } else {
                    throw new Exception('you need to create an account first');
                }
            }
            $id_carrier = $shipping_line[0]['method_id'];
            #create Cart ,inject shipping method request (carrier_id) in to Cart 
            $cartObject = $this->createCartObjectAndSave($billing, $shipping, $line_items, $customerId, $coupon, $id_carrier);
            $cartObject->id_carrier = $shipping_line[0]['method_id'];

            Hook::exec('actionCarrierProcess', array ('cart' => $cartObject));
            if (!$cartObject->update()) {
                return false;
            }
            # set payment method request
            $modulePayment = new FreeOrder();
            $paymentModuleName = $paymentMethod;
            if($paymentMethod == 'paypal') {
                // for create order with exactly module name
                $paymentModuleName = 'icymobipaypal';
            }
            if($paymentMethod == 'razorpay') {
                $paymentModuleName = 'icymobirazorpay';
            }
            $modulePayment->name = $paymentModuleName;
            $modulePayment->displayName = $paymentMethodTitle;
            switch ($paymentMethod) {
                case 'bankwire' :
                    $state = Configuration::get('PS_OS_BANKWIRE');
                    break;
                case 'cheque' :
                    $state = Configuration::get('PS_OS_CHEQUE');
                    break;
                case 'paypal' :
                    $state = Configuration::get('ICYMOBI_PAYPAL_OS_WAITING');
                    break;
                case 'razorpay' :
                    $state = Configuration::get('ICYMOBI_RAZORPAY_OS_PAYMENT_UNCAPTURED');
                    break;
                default:
                    $state = Configuration::get('PS_OS_COD_VALIDATION');
                    break;
            }
            $modulePayment->validateOrder($cartObject->id, $state, $cartObject->getOrderTotal(), $paymentMethod);

            $OrderId = $modulePayment->currentOrder;
            
            $this->insertIcymobiOrderAndDeviceToken($OrderId, $deviceToken);
            
            return $this->getAndFormatOrderByOrderId($OrderId);
        }
        
        public function insertIcymobiOrderAndDeviceToken($orderId, $deviceToken)
        {
            $sql = "INSERT INTO "._DB_PREFIX_."icymobi_order ( id_order, device_token) VALUES ( '" .$orderId.'\' , \''.(($deviceToken != '' && $deviceToken != 'null') ? $deviceToken : NULL)."' )";
            if (!Db::getInstance()->execute($sql)) {
                return false;
            }
            return true;
        }
        
        public function getAndFormatOrderByOrderId($id_order)
        {
            $orderObj = new Order($id_order);
            $billingObj = new Address($orderObj->id_address_invoice);
            $shippingObj = new Address($orderObj->id_address_delivery);
            $currency = Currency::getCurrency($orderObj->id_currency);

            $return = array(
                "id"                   => (int) $id_order,
                "parent_id"            => 0,
                "status"               => $orderObj->current_state,
                "status_text"          => $orderObj->getCurrentStateFull($this->id_lang_default)['name'],
                "order_key"            => $orderObj->reference,
                "number"               => 0,
                "currency"             => ($currency['iso_code']),
                "version"              => null,
                "prices_include_tax"   => $orderObj->total_products_wt,
                "date_created"         => $orderObj->date_add,
                "date_modified"        => $orderObj->date_upd,
                "customer_id"          => (int) $orderObj->id_customer,
                "discount_total"       => $orderObj->total_discounts,
                "discount_tax"         => $orderObj->total_discounts_tax_incl - $orderObj->total_discounts_tax_excl,
                "shipping_total"       => $orderObj->total_shipping_tax_incl,
                "shipping_tax"         => $orderObj->total_shipping_tax_excl,
                "cart_tax"             => '',
                "total"                => $orderObj->total_paid_tax_incl,
                "total_tax"            => $orderObj->total_paid_tax_incl - $orderObj->total_paid_tax_excl,
                "billing"              => array(
                    "first_name" => $billingObj->firstname,
                    "last_name"  => $billingObj->lastname,
                    "company"    => $billingObj->company,
                    "address_1"  => $billingObj->address1,
                    "address_2"  => $billingObj->address2,
                    "city"       => $billingObj->city,
                    "state"      => $billingObj->id_state,
                    "postcode"   => $billingObj->postcode,
                    "country"    => $billingObj->country,
                    "email"      => '',
                    "phone"      => $billingObj->phone ? : $billingObj->phone_mobile,
                ),
                "shipping"             => array(
                    "first_name" => $shippingObj->firstname,
                    "last_name"  => $shippingObj->lastname,
                    "company"    => $shippingObj->company,
                    "address_1"  => $shippingObj->address1,
                    "address_2"  => $shippingObj->address2,
                    "city"       => $shippingObj->city,
                    "state"      => $shippingObj->id_state,
                    "postcode"   => $shippingObj->postcode,
                    "country"    => $shippingObj->country,
                    "email"      => '',
                    "phone"      => $shippingObj->phone ? : $shippingObj->phone_mobile,
                ),
                "payment_method"       => $orderObj->module,
                "payment_method_title" => $orderObj->payment,
                "transaction_id"       => "",
                "customer_ip_address"  => "",
                "customer_user_agent"  => "",
                "created_via"          => "rest-api",
                "customer_note"        => "",
                "date_completed"       => "",
                "date_paid"            => "",
                "cart_hash"            => 0,
                "line_items"           => $this->formatProducts($orderObj->getProductsDetail()),
                "tax_lines"            => array(),
                "shipping_lines"       => $this->formatShipping($orderObj->getShipping()),
                "fee_lines"            => array(),
                "coupon_lines"         => array(),
                "refunds"              => array(),
                "_links"               => array(
                    "self"        => array(
                        0 => array(
                            "href" => ""
                        )
                    ),
                    "collection"  => array(
                        0 => array(
                            "href" => ""
                        )
                    ),
                    "status_text" => $orderObj->current_state
            ));
            return $return;
        }

        public function formatShipping($shipping)
        {
            foreach ($shipping as &$val) {
                $val['id'] = (int) $val['id_carrier'];
                $val['method_id'] = $val['carrier_name'];
                $val['method_title'] = $val['carrier_name'];
                $val['total'] = $val['shipping_cost_tax_incl'];
                $val['total_tax'] = $val['shipping_cost_tax_incl'] - $val['shipping_cost_tax_excl'];
                $val['taxes'] = array();
                unset($val['id_order_invoice']);
                unset($val['weight']);
                unset($val['shipping_cost_tax_excl']);
                unset($val['shipping_cost_tax_incl']);
                unset($val['url']);
                unset($val['id_carrier']);
                unset($val['carrier_name']);
                unset($val['date_add']);
                unset($val['type']);
                unset($val['can_edit']);
                unset($val['tracking_number']);
                unset($val['id_order_carrier']);
                unset($val['order_state_name']);
                unset($val['state_name']);
            }
            return $shipping;
        }

        public function formatProducts($products)
        {
            foreach ($products as &$product) {
                foreach ($product as $field => &$value) {
                    if ($field != 'id_order_detail' &&
                            $field != 'product_name' &&
                            $field != 'product_id' &&
                            $field != 'product_attribute_id' &&
                            $field != 'product_quantity' &&
                            $field != 'product_price' &&
                            $field != 'total_price_tax_incl' &&
                            $field != 'total_price_tax_excl') {
                        unset($products[$field]);
                    }
                }

                $product['id'] = (int) $product['id_order_detail'];
                $product['name'] = $product['product_name'];
                $product['sku'] = '';
                $product['product_id'] = (int) $product['product_id'];
                $product['variation_id'] = (int) $product['product_attribute_id'];
                $product['quantity'] = $product['product_quantity'];
                $product['tax_class'] = '';
                $product['price'] = $product['product_price'];
                $product['subtotal'] = $product['total_price_tax_incl'];
                $product['subtotal_tax'] = '';
                $product['total'] = $product['total_price_tax_incl'];
                $product['total_tax'] = $product['total_price_tax_incl'] - $product['total_price_tax_excl'];
                $product['taxes'] = array();
                $product['meta'] = array();
                unset($product['product_name']);
                unset($product['product_id']);
                unset($product['product_attribute_id']);
                unset($product['product_quantity']);
                unset($product['product_price']);
                unset($product['total_price_tax_incl']);
                unset($product['total_price_tax_excl']);
            }
            return $products;
        }

        /**
         * 
         * @param type $billing
         * @see AuthController processSubmitAccount()
         * @return int id_customer
         */
        public function createAccountForGuest($billing)
        {
            Hook::exec('actionBeforeSubmitAccount');
            $guest_email = $billing['email'];

            if (Validate::isEmail($guest_email) && !empty($guest_email)) {
                if (Customer::customerExists($guest_email)) {
                    throw new Exception('An account using this email address has already been registered.');
                }
            }
            // Preparing customer
            $customer = new Customer();
            $customer->lastname = $billing['last_name'];
            $customer->firstname = $billing['first_name'];
            $customer->email = $guest_email;
            $customer->active = 1;
            $customer->is_guest = 1;
            $customer->passwd = md5(time() . _COOKIE_KEY_);
            if (!$customer->add($autodate = true, $null_values = true)) {
                throw new Exception('create Guest Account Failed!');
            }
            return $customer->id;
        }

        public function changeOrderStatus()
        {
            $orderId = Tools::getValue('id');
            $orderState = Tools::getValue('status');
            $orderObject = new Order($orderId);
            
            if($orderObject->payment == 'paypal') {
                $orderState = ConfigurationCore::get('ICYMOBI_PAYPAL_OS_PAYMENT_VALID');
            } elseif($orderObject->payment == 'razorpay') {
                $orderState = ConfigurationCore::get('ICYMOBI_RAZORPAY_OS_PAYMENT_UNCAPTURED');
            } else {
                $orderState = ConfigurationCore::get('PS_OS_PAYMENT');                
            }
            $orderObject->setCurrentState((int) $orderState);
            
            return $this->getAndFormatOrderByOrderId($orderObject->id);
        }

        public function getListCustomerOrder($customer_id)
        {
            $exists = Customer::customerIdExistsStatic($customer_id);
            if (!$exists) {
                throw new Exception('User not found');
            }
            $page = intval(Tools::getValue('page', 1));
            $per_page = intval(Tools::getValue('per_page', 1));
            $userOrder = Order::getCustomerOrders($customer_id);
            $return = array();
            foreach ($userOrder as $order) {
                $return[] = $this->getAndFormatOrderByOrderId($order['id_order']);
            }
            return $return;
        }

        /**
         * 
         * @param array $address 
         */
        public function createNewAddressObject($address)
        {
            $newAddress = new Address();
            $newAddress->id_country = Country::getByIso($address['country']);
            $newAddress->city = $address['city'];
            $newAddress->alias = $address['address_1'];
            $newAddress->address1 = $address['address_1'];
            $newAddress->address2 = $address['address_2'];
            $newAddress->postcode = $address['postcode'];
            $newAddress->phone = $address['phone'];
            $newAddress->firstname = $address['first_name'];
            $newAddress->lastname = $address['last_name'];
            $newAddress->company = $address['company'];
            $newAddress->save();

            return $newAddress;
        }

    }
    