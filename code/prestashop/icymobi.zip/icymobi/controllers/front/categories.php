<?php

    /**
     * Copyright © 2016 Inspius. All rights reserved.
     * Author: Khanh Tran
     * Author URI: http://inspius.com
     */
    require_once('api.php');

    class IcymobiCategoriesModuleFrontController extends AbstractIcymobiApiFrontController
    {

        protected $id_lang;

        public function __construct()
        {
            parent::__construct();
            $this->id_lang = (Tools::getValue('id_lang')) ? (Tools::getValue('id_lang')) : Configuration::get('PS_LANG_DEFAULT');
        }

        protected function _getResponse()
        {
            switch (ConfigurationCore::get('GENERAL_CATEGORY_DISPLAY')) {
                case 'products' :
                    return $this->_getListCatByProductMode();

                case 'subcategories' :
                    return $this->_getListCatBySubCatMode();
            }
        }

        private function _getListCatByProductMode()
        {
            $categories = $this->_getArrayCategories();

            $linkCore = new Link();
            $return = array();

            foreach ($categories as $key => $category) {
                $productsBelongThisCategory = $this->_getProductByCatId($category['id_category']);
                $count = count( $productsBelongThisCategory );
                $return[$key]['id'] = (int) $category['id_category'];
                $return[$key]['name'] = $category['name'];
                $return[$key]['slug'] = $category['link_rewrite'];
                $return[$key]['parent'] = (int) $category['id_parent'];
                $return[$key]['description'] = htmlspecialchars($category['description']);
                $return[$key]['display'] = '';
                $return[$key]['image']['src'] = 'http://' . $linkCore->getCatImageLink($category['link_rewrite'], $category['id_category'], 'medium_default');
                $return[$key]['menu_order'] = '';
                $return[$key]['count'] = $count ? : 0;
                $return[$key]['products'] = $count ? $productsBelongThisCategory : array();
                $return[$key]['_links']['self']['href'] = _PS_BASE_URL_ . __PS_BASE_URI__ . 'api/categories/' . $category['id_category'];
                $return[$key]['_links']['collection']['href'] = '';
                $return[$key]['_links']['up']['href'] = '';
            }

            return $return;
        }

        private function _getListCatBySubCatMode()
        {
            $linkCore = new Link();
            $categories = $this->_getArrayCategories();
            foreach($categories as &$category) {
                $category['id'] = (int)$category['id_category'];
                $category['parent'] = (int)$category['id_parent'];
                $category['image'] = array(
                    'src' => 'http://' . $linkCore->getCatImageLink($category['link_rewrite'], $category['id'], 'medium_default')
                );
                unset($category['id_parent']);
                unset($category['id_category']);
            }
            $data = array();
            foreach ($categories as $cat) {
                if ($cat['parent'] == 1) {
                    $cat['children'] = $this->get_child_category($cat['id'], $categories);
                    array_push($data, $cat);
                }
            }
            return $data;
        }
        
        /**
         * Recursive function get array include all recursive subcategory 
         * 
         * @param int $parent
         * @param array $categories
         * @return array
         */
        private function get_child_category($parent, $categories)
        {
            $child = array();
            foreach ($categories as $category) {
                if($category['parent']) {
                }
                if ($category['parent'] == (int)$parent) {
                    $category['children'] = $this->get_child_category($category['id'], $categories);
                    if (empty($category['children'])) {
                        $product = $this->_getProductByCatId($category['id']);
                        if (!empty($product)) {
                            $category['products'] = $product;
                        }
                    }
                    array_push($child, $category);
                }
            }
            return $child;
        }
        
        /**
        * Query all id_product which has catagory equal id_catefory
        *
        * @param int $id_category
        * @return array 
        */
        private function _getProductByCatId($id_category)
        {
            $sql =  'SELECT p.id_product, pl.name , p.price FROM ' . _DB_PREFIX_ . 'category_product cp '
                    . 'LEFT JOIN ' . _DB_PREFIX_ . 'product p ON cp.id_product = p.id_product '
                    . 'LEFT JOIN ' . _DB_PREFIX_ . 'product_lang pl ON pl.id_product = p.id_product '
                    . 'WHERE id_category = ' . $id_category . ' AND id_lang = ' . $this->id_lang . ' '
                    . 'LIMIT 10';
            return Db::getInstance()->executeS($sql);
        }
        
        /**
         * Query all id_category with id_parent 
         * 
         * @return array
         */
        private function _getArrayCategories()
        {
            $sql = 'SELECT c.`id_category`, c.`id_parent`, cl.`description`, cl.`name`, cl.`link_rewrite`, cl.`id_lang`
		FROM `' . _DB_PREFIX_ . 'category` c
		LEFT JOIN `' . _DB_PREFIX_ . 'category_lang` cl ON (c.`id_category` = cl.`id_category`' . Shop::addSqlRestrictionOnLang('cl') . ')
		' . Shop::addSqlAssociation('category', 'c') . '
		WHERE cl.`id_lang` = ' . (int) $this->id_lang . '
		GROUP BY c.id_category';

            return DB::getInstance()->executeS($sql);
        }
    }
    