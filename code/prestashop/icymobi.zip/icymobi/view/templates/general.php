<form id="icymobi_theme_options">
	<table class="form-table form-general">
		<tr>
			<th scope="row">
				<label for="general_category_display">Category Page Display</label>
			</th>
			<td>
				<select  name="general_category_display" id="general_category_display" class="regular-select">
					<option value="products"  selected='selected'>
						Show Products
					</option>
					<option value="subcategories" >
						Show Sub Categories
					</option>
				</select>
			</td>
		</tr>	
	</table>

	<h2>Product Images</h2>
	<p>
		These settings affect the display and dimensions of images in your app. After changing these settings you may need to 
		<a href="https://wordpress.org/extend/plugins/regenerate-thumbnails/">
			regenerate your thumbnails
		</a>.
	</p>
	<table class="form-table form-general">
		<tr>
			<th scope="row">
				<label for="general_product_width">Width</label>
			</th>
			<td>
				<input  name="general_product_width" id="general_product_width" type="text" class="regular-text" value="500"> px
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="general_product_height">Height</label>
			</th>
			<td>
				<input  name="general_product_height" id="general_product_height" type="text" class="regular-text" value="500"> 
				px
			</td>
		</tr>	
	</table>
	<h2>Maintenance Settings</h2>
	<table class="form-table form-general">
		<tr>
			<th scope="row">
				<label for="general_enable_app">Maintenance Mode</label>
			</th>
			<td>

				<label for="general_enable_app">
					<input name="general_enable_app" id="general_enable_app" type="checkbox" value="1" > 
					Enable Maintenance Mode							
				</label>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="general_maintenance_text">
					Maintenance Mode Text
				</label>
			</th>
			<td>
				<textarea  name="general_maintenance_text" id="general_maintenance_text" columns="30" rows="10" >
				dsdsd
				</textarea>
			</td>
		</tr>	
	</table>
	<!--</div>-->
	<div id="icymobi-contact-config" class="tab-content">
		<div class="inner">
			<h2>Drop a pin for your business location</h2>
			<div class="googlefind">
				<input id="geocomplete" type="text" class="is_location" placeholder="Type in an address" />
			</div>
			<div class="map_canvas" style="height:400px;width: 700px;"></div>

			<table class="form-table mapdetail">

				<tr style="display:none;">
					<th scope="row">
						<label for="contact_map_lat">Latitude</label>
					</th>
					<td>
						<input data-geo="lat" name="contact_map_lat" id="contact_map_lat" type="text" class="regular-text" value=""> 
					</td>
				</tr>
				<tr style="display:none;">
					<th scope="row">
						<label for="contact_map_lng">Longitude</label>
					</th>
					<td>
						<input data-geo="lng" name="contact_map_lng" id="contact_map_lng" type="text" class="regular-text" value=""> 
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="contact_map_title">Title</label>
					</th>
					<td>
						<input  name="contact_map_title" id="contact_map_title" type="text" class="regular-text" value=""> 
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="contact_map_content">Content</label>
					</th>
					<td>
						<textarea  name="contact_map_content" id="contact_map_content" columns="30" rows="10" ></textarea>
					</td>
				</tr>		
			</table>
		</div>
	</div>
</form>